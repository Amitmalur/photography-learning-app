# User Guide

## Getting Started

CameraLearn is an interactive photography learning app that teaches camera settings through hands-on practice. This guide will help you understand and use all features effectively.

## Main Interface

### Camera Controls Panel (Right Side)
The right panel contains five interactive camera controls:

#### 1. ISO Control
- **Range**: 100 - 6400
- **Purpose**: Controls sensor sensitivity to light
- **Tips**:
  - Low ISO (100-400): Clean images, bright conditions
  - Medium ISO (400-800): Balanced quality and sensitivity
  - High ISO (1600+): Low light conditions, more noise

#### 2. Aperture Control
- **Range**: f/1.4 - f/16
- **Purpose**: Controls depth of field (background blur)
- **Tips**:
  - Wide aperture (f/1.4-f/2.8): Shallow focus, blurred background
  - Medium aperture (f/4-f/5.6): Balanced depth of field
  - Narrow aperture (f/8-f/16): Everything in focus

#### 3. Shutter Speed Control
- **Range**: 1s - 1/1000s
- **Purpose**: Controls motion blur and camera shake
- **Tips**:
  - Fast speeds (1/250s+): Freeze motion
  - Medium speeds (1/60s-1/125s): General photography
  - Slow speeds (1/30s-): Motion blur, use tripod

#### 4. White Balance Control
- **Range**: 2500K - 10000K
- **Purpose**: Adjusts color temperature
- **Tips**:
  - Warm (2500K-4000K): Orange/yellow tint, indoor lighting
  - Neutral (5000K-6500K): Natural daylight colors
  - Cool (7000K+): Blue tint, shade/overcast conditions

#### 5. Focus Control
- **Range**: 0% - 100%
- **Purpose**: Determines focus distance
- **Tips**:
  - Near (0-30%): Focus on foreground objects
  - Middle (30-70%): Balanced focus distance
  - Far (70-100%): Focus on distant subjects

### Live Preview Panel (Left Side)
Shows real-time effects of your camera settings:

- **Image Effects**: Watch how settings change the sample photo
- **Settings Display**: Current values for all camera settings
- **EV Display**: Exposure Value calculation
- **Focus Indicator**: Green circle shows when focus is optimal

## Using the Camera Controls

### Step-by-Step Practice
1. **Start with Default Settings**: Notice the baseline image quality
2. **Adjust One Setting**: Move a single slider and observe changes
3. **Read the Tips**: Each control shows contextual advice
4. **Experiment**: Try extreme values to see dramatic effects
5. **Combine Settings**: Learn how settings work together

### Understanding Visual Effects
- **ISO Noise**: Higher values add grain to the image
- **Aperture Blur**: Lower f-numbers blur the background
- **White Balance**: Changes color warmth/coolness
- **Exposure**: Brightness changes based on ISO and shutter speed

## Practice Challenges

### Accessing Challenges
Scroll down to the "Practice Challenges" section with three difficulty levels:

#### 1. Portrait Mode (Beginner)
- **Goal**: Create shallow depth of field for portraits
- **Target Settings**: ISO 200, f/2.8, 1/125s, 5200K
- **Tips**: Use wide aperture, keep ISO low, focus on subject

#### 2. Landscape Mode (Intermediate)  
- **Goal**: Sharp focus from foreground to background
- **Target Settings**: ISO 100, f/8.0, 1/60s, 5600K
- **Tips**: Use narrow aperture, low ISO, focus on hyperfocal distance

#### 3. Night Photography (Advanced)
- **Goal**: Capture atmosphere in low light
- **Target Settings**: ISO 1600, f/2.8, 1/30s, 4000K
- **Tips**: Higher ISO needed, wide aperture, steady hands

### How to Complete Challenges
1. **Click "Start Challenge"** on any challenge card
2. **Read the Scenario**: Understand the photography situation
3. **Study Target Settings**: See the recommended camera values
4. **Review Tips**: Learn the reasoning behind each setting
5. **Practice**: Try to match the settings using the main controls
6. **Return**: Click "Back to Challenges" to try another

## Interactive Quiz

### Taking the Quiz
1. **Click "Start Quiz"** in the quiz section
2. **Read Each Question**: Photography knowledge questions
3. **Select Answers**: Click on your chosen answer
4. **Progress Through**: Complete all 3 questions
5. **View Results**: See your score and explanation

### Quiz Features
- **Progress Tracking**: Visual progress bar shows completion
- **Scoring System**: Percentage-based results
- **Database Storage**: Results automatically saved
- **Retry Option**: Take the quiz multiple times to improve

### Question Types
- ISO sensitivity and noise
- Aperture and depth of field
- Shutter speed and motion
- General photography techniques

## Tips for Learning

### Effective Practice Methods
1. **Start Simple**: Master one control before combining
2. **Use Real Scenarios**: Think about actual photography situations
3. **Compare Settings**: Try different values for the same scene
4. **Read Explanations**: Understand the "why" behind settings
5. **Take Notes**: Remember successful setting combinations

### Understanding Relationships
- **Exposure Triangle**: ISO, aperture, and shutter speed work together
- **Creative vs Technical**: Balance technical correctness with artistic vision
- **Situational Awareness**: Different scenes require different approaches

### Common Beginner Mistakes
- **High ISO by Default**: Keep ISO low when possible
- **Ignoring Aperture**: Don't overlook depth of field effects
- **Camera Shake**: Use fast enough shutter speeds
- **Wrong White Balance**: Match color temperature to lighting

## Photo Gallery

The bottom section shows sample photos demonstrating different techniques:
- Portrait examples with shallow depth of field
- Landscape photos with deep focus
- Night photography with available light
- Equipment and setup examples

## Progress Tracking

### Automatic Saving
- Quiz results automatically saved to database
- Progress tracked for future reference
- User level and experience points system ready

### Viewing Progress
- Quiz history stored with timestamps
- Score improvements tracked over time
- Challenge completion tracking (coming soon)

## Technical Requirements

### Browser Compatibility
- Modern web browsers (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- Canvas API support for image effects

### Optimal Experience
- Desktop or tablet for best control interaction
- Good internet connection for smooth operation
- Screen resolution 1024x768 or higher

## Troubleshooting

### Common Issues
**Controls Not Responding**:
- Refresh the page
- Check browser JavaScript settings
- Try a different browser

**Image Effects Not Showing**:
- Ensure Canvas API is supported
- Check browser permissions
- Clear browser cache

**Quiz Not Saving**:
- Check internet connection
- Database connection may be down
- Try again after a few minutes

### Getting Help
- Check browser console for error messages
- Verify all controls are working
- Contact support if issues persist

## Learning Path Recommendations

### Beginner Path
1. **Week 1**: Master individual camera controls
2. **Week 2**: Complete all practice challenges
3. **Week 3**: Take quiz multiple times until proficient
4. **Week 4**: Experiment with creative combinations

### Intermediate Path
1. **Focus on Scenarios**: Use challenges as real-world practice
2. **Understand Trade-offs**: Learn when to break "rules"
3. **Speed Practice**: Make adjustments quickly and confidently
4. **Teaching Others**: Explain concepts to reinforce learning

### Advanced Path
1. **Master All Combinations**: Understand how all settings interact
2. **Creative Exploration**: Push boundaries beyond recommended settings
3. **Situational Expertise**: Quickly adapt to any photography scenario
4. **Portfolio Building**: Apply learned techniques to actual photography

## Next Steps

After mastering CameraLearn:
1. **Practice with Real Camera**: Apply learned concepts
2. **Join Photography Communities**: Share knowledge and learn from others
3. **Take Advanced Courses**: Build on solid foundation
4. **Explore Specializations**: Portrait, landscape, street photography, etc.

The goal of CameraLearn is to build confidence and understanding that translates directly to real-world photography success.