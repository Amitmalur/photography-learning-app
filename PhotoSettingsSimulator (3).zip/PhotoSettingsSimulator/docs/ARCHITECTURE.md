# Architecture Documentation

## Overview
CameraLearn is a full-stack educational web application designed to teach photography fundamentals through interactive camera controls, real-time image previews, and gamified learning experiences.

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling and development server
- **Tailwind CSS** for styling with custom photography theme
- **TanStack Query** for server state management
- **Wouter** for client-side routing
- **Canvas API** for real-time image effects

### Backend
- **Express.js** with TypeScript
- **Drizzle ORM** for database operations
- **PostgreSQL** for data persistence
- **Zod** for data validation

### UI Components
- **Radix UI** primitives for accessibility
- **shadcn/ui** component library
- **Lucide React** for icons

## Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable React components
│   │   │   ├── ui/         # shadcn/ui components
│   │   │   ├── camera-controls.tsx
│   │   │   ├── image-preview.tsx
│   │   │   ├── practice-challenges.tsx
│   │   │   ├── quiz-section.tsx
│   │   │   └── photo-gallery.tsx
│   │   ├── hooks/          # Custom React hooks
│   │   │   ├── use-camera-settings.ts
│   │   │   └── use-toast.ts
│   │   ├── lib/            # Utility functions
│   │   │   ├── utils.ts
│   │   │   ├── queryClient.ts
│   │   │   └── image-effects.ts
│   │   ├── pages/          # Page components
│   │   │   ├── camera-learn.tsx
│   │   │   └── not-found.tsx
│   │   ├── data/           # Static content
│   │   │   └── photography-content.ts
│   │   ├── App.tsx         # Main app component
│   │   ├── main.tsx        # Entry point
│   │   └── index.css       # Global styles
│   └── index.html          # HTML template
├── server/                 # Backend Express application
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API route definitions
│   ├── storage.ts         # Database storage layer
│   ├── db.ts              # Database connection
│   └── vite.ts            # Vite integration
├── shared/                # Shared code between frontend/backend
│   └── schema.ts          # Database schema and types
├── docs/                  # Documentation
│   ├── SETUP.md
│   ├── API.md
│   └── ARCHITECTURE.md
├── package.json           # Dependencies and scripts
├── drizzle.config.ts      # Database configuration
├── tailwind.config.ts     # Tailwind CSS config
├── vite.config.ts         # Vite build config
└── README.md              # Main documentation
```

## Data Flow

### Camera Settings Flow
1. User adjusts camera control sliders
2. `useCameraSettings` hook updates state
3. Settings passed to `ImagePreview` component
4. Canvas effects applied via `image-effects.ts`
5. Real-time visual feedback displayed

### Quiz Flow
1. User starts quiz in `QuizSection` component
2. Questions displayed with interactive options
3. Answers tracked in local state
4. On completion, results sent to API
5. Results saved to database via storage layer

### Practice Challenges Flow
1. User selects challenge from grid
2. Challenge details and target settings displayed
3. User attempts to match settings
4. Educational tips provided for guidance

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  level INTEGER DEFAULT 1,
  experience INTEGER DEFAULT 0,
  completed_challenges TEXT[] DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);
```

### User Progress Table
```sql
CREATE TABLE user_progress (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  lesson_id TEXT NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  score INTEGER,
  completed_at TIMESTAMP
);
```

### Quiz Results Table
```sql
CREATE TABLE quiz_results (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  quiz_type TEXT NOT NULL,
  score INTEGER NOT NULL,
  total_questions INTEGER NOT NULL,
  completed_at TIMESTAMP DEFAULT NOW()
);
```

## Key Components

### CameraControls
- Interactive sliders for camera settings
- Educational tooltips and tips
- Real-time value display
- Visual feedback for setting ranges

### ImagePreview
- Canvas-based image manipulation
- Real-time effects application
- EV calculation display
- Camera settings summary

### QuizSection
- Interactive quiz interface
- Progress tracking
- Database integration for results
- Scoring and feedback system

### PracticeChallenges
- Scenario-based learning
- Target setting challenges
- Educational tips and guidance
- Difficulty progression

## Image Effects System

### Canvas Processing
Located in `client/src/lib/image-effects.ts`:

- **ISO Noise**: Simulates sensor noise at high ISO values
- **Aperture Blur**: Creates depth of field effects
- **White Balance**: Adjusts color temperature
- **Exposure**: Modifies brightness based on settings

### Effect Pipeline
1. Clear canvas
2. Draw base image
3. Apply ISO noise effect
4. Apply aperture blur
5. Adjust white balance
6. Modify exposure

## State Management

### Local State
- Camera settings via `useCameraSettings`
- Quiz progress and answers
- Challenge selection and completion

### Server State
- User data and progress
- Quiz results history
- Managed by TanStack Query

### Persistence
- Database storage for user data
- Local storage for preferences
- Session state for current progress

## API Design

### RESTful Endpoints
- `/api/users` - User management
- `/api/users/:id/progress` - Learning progress
- `/api/users/:id/quiz-results` - Quiz history
- `/api/health` - System status

### Data Validation
- Zod schemas for request validation
- Type-safe database operations
- Error handling and responses

## Security Considerations

### Current Implementation
- Basic user creation and storage
- Demo user (ID: 1) for testing
- No authentication system yet

### Future Enhancements
- JWT-based authentication
- Password hashing (bcrypt)
- Rate limiting for API endpoints
- Input sanitization and validation

## Performance Optimizations

### Frontend
- React Query caching
- Component memoization
- Lazy loading for routes
- Optimized image processing

### Backend
- Database connection pooling
- Efficient query patterns
- Response compression
- Static asset serving

## Development Workflow

### Local Development
1. `npm run dev` - Start development server
2. Hot module replacement for instant updates
3. TypeScript type checking
4. Tailwind CSS compilation

### Database Management
1. `npm run db:push` - Push schema changes
2. `npm run db:studio` - Database GUI
3. Drizzle migrations for schema versioning

### Build Process
1. `npm run build` - Production build
2. Vite optimizes frontend assets
3. Express server bundled separately
4. Static files served efficiently

## Deployment Architecture

### Recommended Stack
- **Frontend**: Vercel, Netlify, or Replit Deployments
- **Backend**: Railway, Heroku, or VPS
- **Database**: Neon, Supabase, or managed PostgreSQL
- **CDN**: Cloudflare for static assets

### Environment Variables
```env
DATABASE_URL=postgresql://...
NODE_ENV=production
PORT=5000
```

## Monitoring and Maintenance

### Health Checks
- `/api/health` endpoint for monitoring
- Database connectivity verification
- Error logging and tracking

### Metrics
- User engagement with camera controls
- Quiz completion rates
- Challenge success metrics
- Performance monitoring