# API Documentation

## Base URL
```
http://localhost:5000/api
```

## Authentication
Currently using demo user (ID: 1) for testing. In production, implement proper authentication.

## Endpoints

### Health Check
```http
GET /api/health
```
**Response:**
```json
{
  "status": "ok",
  "database": "connected"
}
```

### Users

#### Get User
```http
GET /api/users/:id
```
**Response:**
```json
{
  "id": 1,
  "username": "demo_user",
  "password": "demo123",
  "level": 1,
  "experience": 0,
  "completedChallenges": [],
  "createdAt": "2025-06-30T18:19:55.236Z"
}
```

#### Create User
```http
POST /api/users
Content-Type: application/json

{
  "username": "newuser",
  "password": "password123"
}
```

### User Progress

#### Get User Progress
```http
GET /api/users/:id/progress
```
**Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "lessonId": "camera-basics",
    "completed": true,
    "score": 85,
    "completedAt": "2025-06-30T18:30:00.000Z"
  }
]
```

#### Create Progress Entry
```http
POST /api/users/:id/progress
Content-Type: application/json

{
  "lessonId": "camera-basics",
  "score": 85
}
```

#### Update Progress
```http
PUT /api/users/:id/progress/:lessonId
Content-Type: application/json

{
  "completed": true,
  "score": 90
}
```

### Quiz Results

#### Get Quiz Results
```http
GET /api/users/:id/quiz-results
```
**Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "quizType": "photography-basics",
    "score": 2,
    "totalQuestions": 3,
    "completedAt": "2025-06-30T18:45:00.000Z"
  }
]
```

#### Save Quiz Result
```http
POST /api/users/:id/quiz-results
Content-Type: application/json

{
  "quizType": "photography-basics",
  "score": 3,
  "totalQuestions": 3
}
```

## Error Responses

### 400 Bad Request
```json
{
  "error": "Invalid user data"
}
```

### 404 Not Found
```json
{
  "error": "User not found"
}
```

### 409 Conflict
```json
{
  "error": "Username already exists"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal server error"
}
```

## Data Models

### User
```typescript
interface User {
  id: number;
  username: string;
  password: string;
  level: number | null;
  experience: number | null;
  completedChallenges: string[] | null;
  createdAt: Date | null;
}
```

### UserProgress
```typescript
interface UserProgress {
  id: number;
  userId: number | null;
  lessonId: string;
  completed: boolean | null;
  score: number | null;
  completedAt: Date | null;
}
```

### QuizResult
```typescript
interface QuizResult {
  id: number;
  userId: number | null;
  quizType: string;
  score: number;
  totalQuestions: number;
  completedAt: Date | null;
}
```