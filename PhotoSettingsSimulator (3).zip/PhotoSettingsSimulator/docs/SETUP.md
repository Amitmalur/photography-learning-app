# Setup Guide

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Setup Environment**
   Create `.env` file:
   ```env
   DATABASE_URL=postgresql://username:password@host:port/database_name
   NODE_ENV=development
   ```

3. **Initialize Database**
   ```bash
   npm run db:push
   ```

4. **Start Development Server**
   ```bash
   npm run dev
   ```

5. **Access Application**
   Open http://localhost:5000

## Database Setup Options

### Cloud Databases (Recommended)
- **Neon**: https://neon.tech (Free tier)
- **Supabase**: https://supabase.com
- **Railway**: https://railway.app
- **PlanetScale**: https://planetscale.com

### Local PostgreSQL
```sql
CREATE DATABASE camera_learn;
```

## Create Demo User
```bash
curl -X POST http://localhost:5000/api/users \
  -H "Content-Type: application/json" \
  -d '{"username": "demo_user", "password": "demo123"}'
```

## Troubleshooting

### Database Issues
- Verify DATABASE_URL format
- Check database server status
- Run `npm run db:push` to create tables

### Port Conflicts
- Kill process on port 5000
- Or modify port in server config

### Module Errors
```bash
rm -rf node_modules package-lock.json
npm install
```