# Documentation Index

Welcome to the CameraLearn documentation. This folder contains comprehensive guides for using, understanding, and deploying the photography learning application.

## Quick Links

### For Users
- **[User Guide](USER_GUIDE.md)** - Complete guide to using the application
- **[Setup Guide](SETUP.md)** - Quick installation and setup instructions

### For Developers
- **[Architecture](ARCHITECTURE.md)** - Technical architecture and system design
- **[API Documentation](API.md)** - Complete API reference with examples
- **[Deployment Guide](DEPLOYMENT.md)** - Production deployment instructions

## Documentation Overview

### SETUP.md
Quick start guide with essential steps:
- Installation requirements
- Environment configuration
- Database setup options
- Basic troubleshooting

### USER_GUIDE.md
Comprehensive user manual covering:
- Camera controls explanation
- Practice challenges walkthrough
- Interactive quiz features
- Learning tips and strategies

### ARCHITECTURE.md
Technical documentation including:
- System architecture overview
- Technology stack details
- Project structure explanation
- Database schema design
- Component relationships

### API.md
Complete API reference with:
- Endpoint documentation
- Request/response examples
- Error handling
- Data models
- Authentication details

### DEPLOYMENT.md
Production deployment guide covering:
- Platform-specific instructions
- Environment configuration
- Database setup
- Security considerations
- Monitoring and maintenance

## Getting Help

1. **Quick Setup**: Start with [SETUP.md](SETUP.md)
2. **Learning to Use**: Read [USER_GUIDE.md](USER_GUIDE.md)
3. **Development**: Check [ARCHITECTURE.md](ARCHITECTURE.md)
4. **API Integration**: Reference [API.md](API.md)
5. **Going Live**: Follow [DEPLOYMENT.md](DEPLOYMENT.md)

## Contributing

When updating documentation:
- Keep examples current and working
- Update related files when making changes
- Test all code examples before publishing
- Maintain consistent formatting and style

## Support

For issues not covered in these guides:
- Check the main [README.md](../README.md) in the project root
- Review browser console for error messages
- Verify database connectivity with `/api/health`
- Ensure all environment variables are properly set