# Deployment Guide

## Overview
This guide covers deploying the CameraLearn photography app to various platforms.

## Prerequisites
- Built and tested application locally
- Database setup and configured
- Environment variables prepared

## Build for Production

### 1. Install Dependencies
```bash
npm install
```

### 2. Build Application
```bash
npm run build
```

This creates optimized production files:
- Frontend assets in `dist/public/`
- Server bundle in `dist/index.js`

## Environment Variables

Create production environment variables:

```env
# Required
DATABASE_URL=postgresql://username:password@host:port/database_name
NODE_ENV=production

# Optional
PORT=5000
PGHOST=your-db-host
PGPORT=5432
PGUSER=your-username
PGPASSWORD=your-password
PGDATABASE=your-database
```

## Deployment Options

### Option 1: Replit Deployments (Recommended)

1. **One-Click Deploy**
   - Click the "Deploy" button in your Replit
   - Configure environment variables in deployment settings
   - Set `DATABASE_URL` to your PostgreSQL connection string
   - Deploy automatically handles build and serving

2. **Custom Domain** (Optional)
   - Configure custom domain in deployment settings
   - SSL/TLS handled automatically

### Option 2: Railway

1. **Connect Repository**
   ```bash
   # Install Railway CLI
   npm install -g @railway/cli
   
   # Login and deploy
   railway login
   railway link
   railway up
   ```

2. **Configure Environment**
   ```bash
   railway variables set DATABASE_URL=postgresql://...
   railway variables set NODE_ENV=production
   ```

3. **Database Setup**
   ```bash
   # Add PostgreSQL service
   railway add postgresql
   
   # Run migrations
   railway run npm run db:push
   ```

### Option 3: Vercel + Railway Database

1. **Frontend on Vercel**
   ```bash
   npm install -g vercel
   vercel
   ```

2. **Backend on Railway**
   - Deploy backend separately to Railway
   - Update frontend API endpoints to Railway backend URL

3. **Environment Variables**
   ```bash
   # In Vercel dashboard
   VITE_API_URL=https://your-backend.railway.app
   ```

### Option 4: Heroku

1. **Create Heroku App**
   ```bash
   # Install Heroku CLI
   heroku create camera-learn-app
   ```

2. **Add PostgreSQL**
   ```bash
   heroku addons:create heroku-postgresql:hobby-dev
   ```

3. **Configure Build**
   ```json
   // package.json
   {
     "scripts": {
       "build": "npm run build",
       "start": "node dist/index.js",
       "heroku-postbuild": "npm run build"
     }
   }
   ```

4. **Deploy**
   ```bash
   git push heroku main
   heroku run npm run db:push
   ```

### Option 5: DigitalOcean App Platform

1. **Create App**
   - Connect GitHub repository
   - Configure build and run commands

2. **Environment Variables**
   ```
   DATABASE_URL: ${db.DATABASE_URL}
   NODE_ENV: production
   ```

3. **Database Component**
   - Add managed PostgreSQL database
   - Database URL automatically provided

## Database Setup

### Cloud Database Providers

#### Neon (Recommended)
1. Create account at https://neon.tech
2. Create new project and database
3. Copy connection string
4. Set as `DATABASE_URL` environment variable

#### Supabase
1. Create project at https://supabase.com
2. Go to Settings > Database
3. Copy connection string
4. Replace password with your actual password

#### PlanetScale
1. Create database at https://planetscale.com
2. Create connection string
3. Note: PlanetScale uses MySQL, may require schema adjustments

### Migration
After deployment, run database migration:
```bash
npm run db:push
```

## SSL/TLS Configuration
Most platforms handle SSL automatically:
- Replit Deployments: Automatic HTTPS
- Railway: Automatic SSL certificates
- Vercel: Automatic HTTPS
- Heroku: Automatic SSL for custom domains

## Performance Optimization

### Frontend Optimizations
- Static asset compression (handled by Vite)
- Image optimization
- Code splitting and lazy loading
- CDN integration for assets

### Backend Optimizations
- Database connection pooling
- Response compression
- Efficient query patterns
- Caching strategies

## Monitoring and Logging

### Application Monitoring
```javascript
// Add to server/index.ts
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});
```

### Database Monitoring
- Monitor connection counts
- Track query performance
- Set up alerts for errors

### Health Checks
```bash
curl https://your-app.com/api/health
```

## Post-Deployment Steps

### 1. Verify Deployment
- Test all camera controls
- Complete a quiz and verify database save
- Try practice challenges
- Check API endpoints

### 2. Create Demo User
```bash
curl -X POST https://your-app.com/api/users \
  -H "Content-Type: application/json" \
  -d '{"username": "demo_user", "password": "demo123"}'
```

### 3. Test Database Operations
```bash
# Check health
curl https://your-app.com/api/health

# Test user creation
curl -X POST https://your-app.com/api/users \
  -H "Content-Type: application/json" \
  -d '{"username": "test", "password": "test123"}'

# Test quiz result
curl -X POST https://your-app.com/api/users/1/quiz-results \
  -H "Content-Type: application/json" \
  -d '{"quizType": "test", "score": 3, "totalQuestions": 3}'
```

## Troubleshooting

### Common Issues

**Build Failures**
- Check Node.js version compatibility
- Verify all dependencies installed
- Review build logs for specific errors

**Database Connection Issues**
- Verify DATABASE_URL format
- Check database server status
- Ensure database accepts external connections
- Verify SSL requirements

**Environment Variable Issues**
- Check variable names (case sensitive)
- Verify values are properly set
- Review platform-specific documentation

**Performance Issues**
- Monitor database query performance
- Check server resources (CPU, memory)
- Review network connectivity
- Consider adding caching

### Debugging Steps

1. **Check Logs**
   ```bash
   # Railway
   railway logs
   
   # Heroku
   heroku logs --tail
   
   # Vercel
   vercel logs
   ```

2. **Test API Endpoints**
   ```bash
   curl https://your-app.com/api/health
   ```

3. **Database Connectivity**
   ```bash
   # Test connection
   psql $DATABASE_URL -c "SELECT NOW();"
   ```

## Security Considerations

### Production Security
- Use environment variables for secrets
- Enable CORS for specific domains only
- Implement rate limiting
- Add input validation and sanitization
- Use HTTPS for all traffic

### Database Security
- Use connection pooling
- Implement prepared statements
- Regular security updates
- Monitor for suspicious activity

## Scaling Considerations

### Horizontal Scaling
- Stateless application design
- Database connection pooling
- Load balancer configuration
- Session management

### Database Scaling
- Read replicas for analytics
- Connection pooling
- Query optimization
- Indexing strategies

## Backup and Recovery

### Database Backups
```bash
# Manual backup
pg_dump $DATABASE_URL > backup.sql

# Restore
psql $DATABASE_URL < backup.sql
```

### Automated Backups
- Enable automatic backups on database provider
- Test restore procedures regularly
- Store backups in secure locations

## Maintenance

### Regular Tasks
- Monitor application performance
- Update dependencies
- Review security vulnerabilities
- Backup database regularly
- Monitor disk space and resources

### Updates
```bash
# Update dependencies
npm update

# Rebuild and redeploy
npm run build
# Deploy using platform-specific method
```