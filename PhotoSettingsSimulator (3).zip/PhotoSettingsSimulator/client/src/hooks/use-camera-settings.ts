import { useState, useCallback } from "react";

export interface CameraSettings {
  iso: number;
  aperture: number;
  shutterSpeed: number;
  whiteBalance: number;
  focus: number;
}

export function useCameraSettings() {
  const [settings, setSettings] = useState<CameraSettings>({
    iso: 400,
    aperture: 2.8,
    shutterSpeed: 60,
    whiteBalance: 5600,
    focus: 0.8
  });

  const updateSetting = useCallback((setting: keyof CameraSettings, value: number) => {
    setSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  }, []);

  return { settings, updateSetting };
}
