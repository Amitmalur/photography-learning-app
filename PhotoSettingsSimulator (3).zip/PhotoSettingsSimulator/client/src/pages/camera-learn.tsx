import { useState } from "react";
import { Camera, Star, Play, Eye, Download, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import ImagePreview from "@/components/image-preview";
import CameraControls from "@/components/camera-controls";
import CameraTutorial from "@/components/camera-tutorial";
import SmartHints from "@/components/smart-hints";
import LearningProgress from "@/components/learning-progress";
import PracticeChallenges from "@/components/practice-challenges";
import QuizSection from "@/components/quiz-section";
import PhotoGallery from "@/components/photo-gallery";
import { useCameraSettings } from "@/hooks/use-camera-settings";

export default function CameraLearn() {
  const { settings, updateSetting } = useCameraSettings();
  const [currentLesson] = useState({ current: 3, total: 8 });
  const [activeTab, setActiveTab] = useState<'tutorial' | 'practice' | 'quiz' | 'progress'>('tutorial');

  return (
    <div className="min-h-screen bg-light-grey">
      {/* Header */}
      <header className="bg-camera-dark text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Camera className="h-8 w-8 lens-blue" />
              <h1 className="text-2xl font-roboto font-bold">CameraLearn</h1>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#learn" className="hover:text-lens-blue transition-colors">Learn</a>
              <a href="#practice" className="hover:text-lens-blue transition-colors">Practice</a>
              <a href="#quiz" className="hover:text-lens-blue transition-colors">Quiz</a>
              <div className="flex items-center space-x-2 bg-camera-dark/50 rounded-full px-3 py-1">
                <Star className="h-4 w-4 warm-orange" fill="currentColor" />
                <span className="text-sm">Level 3</span>
              </div>
            </nav>
            <Button variant="ghost" className="md:hidden text-white">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-roboto font-semibold charcoal">Camera Settings Basics</h2>
            <span className="text-sm text-charcoal/70">{currentLesson.current} of {currentLesson.total} lessons completed</span>
          </div>
          <Progress value={(currentLesson.current / currentLesson.total) * 100} className="h-2" />
        </div>

        {/* Navigation Tabs */}
        <div className="mb-8">
          <div className="flex space-x-1 bg-camera-dark rounded-lg p-1">
            <Button
              onClick={() => setActiveTab('tutorial')}
              variant={activeTab === 'tutorial' ? 'default' : 'ghost'}
              className={`flex-1 ${activeTab === 'tutorial' ? 'bg-lens-blue text-white' : 'text-white hover:bg-white/10'}`}
            >
              <Eye className="h-4 w-4 mr-2" />
              Interactive Tutorial
            </Button>
            <Button
              onClick={() => setActiveTab('progress')}
              variant={activeTab === 'progress' ? 'default' : 'ghost'}
              className={`flex-1 ${activeTab === 'progress' ? 'bg-lens-blue text-white' : 'text-white hover:bg-white/10'}`}
            >
              <Star className="h-4 w-4 mr-2" />
              Learning Path
            </Button>
            <Button
              onClick={() => setActiveTab('practice')}
              variant={activeTab === 'practice' ? 'default' : 'ghost'}
              className={`flex-1 ${activeTab === 'practice' ? 'bg-lens-blue text-white' : 'text-white hover:bg-white/10'}`}
            >
              <Play className="h-4 w-4 mr-2" />
              Practice
            </Button>
            <Button
              onClick={() => setActiveTab('quiz')}
              variant={activeTab === 'quiz' ? 'default' : 'ghost'}
              className={`flex-1 ${activeTab === 'quiz' ? 'bg-lens-blue text-white' : 'text-white hover:bg-white/10'}`}
            >
              <Info className="h-4 w-4 mr-2" />
              Quiz
            </Button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'tutorial' && (
          <>
            <div className="mb-12">
              <CameraTutorial 
                settings={settings} 
                onSettingChange={updateSetting}
                onTutorialComplete={() => console.log('Tutorial completed!')}
              />
            </div>

            <div className="grid lg:grid-cols-2 gap-6 mb-12">
              <ImagePreview settings={settings} />
              <CameraControls settings={settings} onSettingChange={updateSetting} />
            </div>
          </>
        )}

        {activeTab === 'progress' && (
          <LearningProgress 
            settings={settings}
            onModuleSelect={(moduleId) => console.log('Selected module:', moduleId)}
            onSettingChange={updateSetting}
          />
        )}

        {activeTab === 'practice' && (
          <>
            <PracticeChallenges />
            <PhotoGallery />
          </>
        )}

        {activeTab === 'quiz' && (
          <QuizSection />
        )}
        
        {/* Smart Hints System */}
        <SmartHints settings={settings} onSettingChange={updateSetting} />
      </main>

      {/* Footer */}
      <footer className="bg-camera-dark text-white mt-16 py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Camera className="h-5 w-5 lens-blue" />
                <span className="font-roboto font-bold">CameraLearn</span>
              </div>
              <p className="text-sm text-gray-300">Master photography through interactive learning and practice.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Learn</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-lens-blue transition-colors">Camera Basics</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Composition</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Lighting</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Practice</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-lens-blue transition-colors">Challenges</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Exercises</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Projects</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Community</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li><a href="#" className="hover:text-lens-blue transition-colors">Gallery</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Forums</a></li>
                <li><a href="#" className="hover:text-lens-blue transition-colors">Support</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-300">
            <p>&copy; 2024 CameraLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
