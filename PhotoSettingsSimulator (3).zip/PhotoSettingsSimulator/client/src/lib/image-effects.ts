import type { CameraSettings } from "@/hooks/use-camera-settings";

export function applyImageEffects(
  ctx: CanvasRenderingContext2D,
  image: HTMLImageElement,
  settings: CameraSettings
) {
  // Clear canvas
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  
  // Draw base image
  ctx.drawImage(image, 0, 0, ctx.canvas.width, ctx.canvas.height);
  
  // Apply ISO noise effect
  applyISONoise(ctx, settings.iso);
  
  // Apply aperture blur effect (simplified)
  applyApertureEffect(ctx, settings.aperture);
  
  // Apply white balance tint
  applyWhiteBalance(ctx, settings.whiteBalance);
  
  // Apply exposure adjustment based on ISO and shutter speed
  applyExposure(ctx, settings.iso, settings.shutterSpeed);
}

function applyISONoise(ctx: CanvasRenderingContext2D, iso: number) {
  if (iso <= 400) return;
  
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const data = imageData.data;
  
  // Add noise based on ISO value
  const noiseIntensity = Math.min((iso - 400) / 6000, 0.3);
  
  for (let i = 0; i < data.length; i += 4) {
    if (Math.random() < noiseIntensity * 0.1) {
      const noise = (Math.random() - 0.5) * 60 * noiseIntensity;
      data[i] = Math.max(0, Math.min(255, data[i] + noise));     // R
      data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + noise)); // G
      data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + noise)); // B
    }
  }
  
  ctx.putImageData(imageData, 0, 0);
}

function applyApertureEffect(ctx: CanvasRenderingContext2D, aperture: number) {
  // Simplified depth of field effect using blur
  if (aperture >= 5.6) return;
  
  const blurAmount = Math.max(0, (5.6 - aperture) * 2);
  ctx.filter = `blur(${blurAmount}px)`;
  
  // Redraw with blur effect
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.putImageData(imageData, 0, 0);
  
  // Reset filter
  ctx.filter = 'none';
}

function applyWhiteBalance(ctx: CanvasRenderingContext2D, whiteBalance: number) {
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const data = imageData.data;
  
  // Calculate color temperature adjustment
  let redAdjust = 1;
  let blueAdjust = 1;
  
  if (whiteBalance < 5600) {
    // Warmer (more orange/red)
    redAdjust = 1 + (5600 - whiteBalance) / 10000;
    blueAdjust = 1 - (5600 - whiteBalance) / 15000;
  } else if (whiteBalance > 5600) {
    // Cooler (more blue)
    redAdjust = 1 - (whiteBalance - 5600) / 15000;
    blueAdjust = 1 + (whiteBalance - 5600) / 10000;
  }
  
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, data[i] * redAdjust));     // R
    data[i + 2] = Math.max(0, Math.min(255, data[i + 2] * blueAdjust)); // B
  }
  
  ctx.putImageData(imageData, 0, 0);
}

function applyExposure(ctx: CanvasRenderingContext2D, iso: number, shutterSpeed: number) {
  const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const data = imageData.data;
  
  // Calculate exposure value (simplified EV calculation)
  const baseExposure = 1;
  const isoFactor = iso / 400; // ISO 400 as baseline
  const shutterFactor = shutterSpeed / 60; // 1/60s as baseline
  
  const exposureAdjustment = baseExposure * isoFactor / shutterFactor;
  const brightness = Math.max(0.3, Math.min(2.0, exposureAdjustment));
  
  for (let i = 0; i < data.length; i += 4) {
    data[i] = Math.max(0, Math.min(255, data[i] * brightness));     // R
    data[i + 1] = Math.max(0, Math.min(255, data[i + 1] * brightness)); // G
    data[i + 2] = Math.max(0, Math.min(255, data[i + 2] * brightness)); // B
  }
  
  ctx.putImageData(imageData, 0, 0);
}
