export interface PhotographyTip {
  setting: string;
  title: string;
  description: string;
  examples: string[];
}

export interface Challenge {
  id: string;
  title: string;
  scenario: string;
  targetSettings: {
    iso: number;
    aperture: number;
    shutterSpeed: number;
    whiteBalance: number;
  };
  tips: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export const photographyTips: PhotographyTip[] = [
  {
    setting: "iso",
    title: "Understanding ISO",
    description: "ISO controls your camera sensor's sensitivity to light. Higher ISO allows shooting in darker conditions but introduces more noise (grain).",
    examples: [
      "ISO 100-200: Bright daylight, studio lighting",
      "ISO 400-800: Overcast days, indoor with good light",
      "ISO 1600-3200: Low light, evening photography",
      "ISO 6400+: Very low light, night photography"
    ]
  },
  {
    setting: "aperture",
    title: "Mastering Aperture",
    description: "Aperture controls depth of field - how much of your image is in sharp focus. Smaller f-numbers mean wider apertures and shallower depth of field.",
    examples: [
      "f/1.4-f/2.8: Portrait photography, subject isolation",
      "f/4-f/5.6: General photography, moderate depth",
      "f/8-f/11: Landscape photography, maximum sharpness",
      "f/16-f/22: Deep focus, everything sharp"
    ]
  },
  {
    setting: "shutterSpeed",
    title: "Controlling Motion",
    description: "Shutter speed determines how motion appears in your photos. Fast speeds freeze action, slow speeds create motion blur.",
    examples: [
      "1/1000s+: Sports, wildlife, freezing fast motion",
      "1/250-1/500s: General photography, handheld shots",
      "1/60-1/125s: Portraits, careful handheld work",
      "1/30s or slower: Intentional motion blur, tripod required"
    ]
  },
  {
    setting: "whiteBalance",
    title: "Color Temperature",
    description: "White balance ensures colors look natural under different lighting conditions. Measured in Kelvin (K).",
    examples: [
      "2500-3500K: Tungsten/incandescent lighting (warm)",
      "4000-5000K: Fluorescent lighting (neutral)",
      "5500-6500K: Daylight (neutral white)",
      "7000-10000K: Shade, overcast sky (cool blue)"
    ]
  }
];

export const challenges: Challenge[] = [
  {
    id: "portrait-golden-hour",
    title: "Golden Hour Portrait",
    scenario: "Capture a portrait during golden hour with beautiful background blur",
    targetSettings: {
      iso: 200,
      aperture: 2.8,
      shutterSpeed: 125,
      whiteBalance: 5200
    },
    tips: [
      "Use wide aperture for shallow depth of field",
      "Keep ISO low for clean image quality",
      "Adjust white balance for warm golden light",
      "Use fast enough shutter speed to avoid camera shake"
    ],
    difficulty: "beginner"
  },
  {
    id: "landscape-sharp",
    title: "Sharp Landscape",
    scenario: "Photograph a landscape with everything in focus from foreground to background",
    targetSettings: {
      iso: 100,
      aperture: 8.0,
      shutterSpeed: 60,
      whiteBalance: 5600
    },
    tips: [
      "Use narrow aperture for deep depth of field",
      "Keep ISO low for maximum quality",
      "Use tripod for stability with slower shutter",
      "Daylight white balance for natural colors"
    ],
    difficulty: "intermediate"
  },
  {
    id: "night-street",
    title: "Night Street Photography",
    scenario: "Capture the atmosphere of a city street at night with available light",
    targetSettings: {
      iso: 1600,
      aperture: 2.8,
      shutterSpeed: 30,
      whiteBalance: 4000
    },
    tips: [
      "Higher ISO needed for low light conditions",
      "Wide aperture to gather more light",
      "Balance shutter speed for handheld shooting",
      "Adjust white balance for mixed lighting"
    ],
    difficulty: "advanced"
  }
];
