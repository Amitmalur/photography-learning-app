import { useState } from "react";
import { Play, Clock, Star, Target, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface Challenge {
  id: number;
  title: string;
  description: string;
  image: string;
  difficulty: string;
  duration: string;
  stars: number;
  difficultyColor: string;
  targetSettings: CameraSettings;
  scenario: string;
  tips: string[];
}

export default function PracticeChallenges() {
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [challengeComplete, setChallengeComplete] = useState(false);

  const challenges: Challenge[] = [
    {
      id: 1,
      title: "Portrait Mode",
      description: "Create beautiful portraits with shallow depth of field",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      difficulty: "Beginner",
      duration: "5 min",
      stars: 3,
      difficultyColor: "bg-warm-orange",
      targetSettings: {
        iso: 200,
        aperture: 2.8,
        shutterSpeed: 125,
        whiteBalance: 5200,
        focus: 0.7
      },
      scenario: "You're photographing a person outdoors during golden hour. The goal is to create a beautiful portrait with the subject in sharp focus and a blurred background.",
      tips: [
        "Use a wide aperture (low f-number) for shallow depth of field",
        "Keep ISO low for clean image quality",
        "Adjust white balance for warm golden light",
        "Focus on the subject's eyes"
      ]
    },
    {
      id: 2,
      title: "Landscape Mode",
      description: "Capture sharp landscapes with proper exposure",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      difficulty: "Intermediate",
      duration: "8 min",
      stars: 2,
      difficultyColor: "bg-lens-blue",
      targetSettings: {
        iso: 100,
        aperture: 8.0,
        shutterSpeed: 60,
        whiteBalance: 5600,
        focus: 0.9
      },
      scenario: "You want to capture a sweeping landscape with everything from the foreground rocks to the distant mountains in sharp focus.",
      tips: [
        "Use a narrow aperture for deep depth of field",
        "Keep ISO as low as possible for maximum quality",
        "Focus on the hyperfocal distance",
        "Use daylight white balance for natural colors"
      ]
    },
    {
      id: 3,
      title: "Night Photography",
      description: "Master low-light photography techniques",
      image: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      difficulty: "Advanced",
      duration: "12 min",
      stars: 0,
      difficultyColor: "bg-camera-dark",
      targetSettings: {
        iso: 1600,
        aperture: 2.8,
        shutterSpeed: 30,
        whiteBalance: 4000,
        focus: 0.8
      },
      scenario: "You're capturing the atmosphere of a city street at night, balancing the available light from street lamps and neon signs.",
      tips: [
        "Higher ISO is necessary for low light conditions",
        "Wide aperture helps gather more light",
        "Balance shutter speed to avoid camera shake",
        "Adjust white balance for mixed lighting sources"
      ]
    }
  ];

  const checkChallengeCompletion = (userSettings: CameraSettings, target: CameraSettings): number => {
    const isoMatch = Math.abs(userSettings.iso - target.iso) / target.iso <= 0.2;
    const apertureMatch = Math.abs(userSettings.aperture - target.aperture) / target.aperture <= 0.2;
    const shutterMatch = Math.abs(userSettings.shutterSpeed - target.shutterSpeed) / target.shutterSpeed <= 0.3;
    const wbMatch = Math.abs(userSettings.whiteBalance - target.whiteBalance) / target.whiteBalance <= 0.1;
    const focusMatch = Math.abs(userSettings.focus - target.focus) <= 0.2;
    
    const matches = [isoMatch, apertureMatch, shutterMatch, wbMatch, focusMatch];
    return matches.filter(Boolean).length;
  };

  const startChallenge = (challenge: Challenge) => {
    setSelectedChallenge(challenge);
    setChallengeComplete(false);
  };

  const resetChallenge = () => {
    setSelectedChallenge(null);
    setChallengeComplete(false);
  };

  if (selectedChallenge) {
    return (
      <div className="mt-12">
        <Card className="bg-white shadow-lg">
          <CardContent className="p-8">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-roboto font-bold charcoal">Challenge: {selectedChallenge.title}</h2>
                <Badge className={`${selectedChallenge.difficultyColor} text-white`}>
                  {selectedChallenge.difficulty}
                </Badge>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <img
                  src={selectedChallenge.image}
                  alt={selectedChallenge.title}
                  className="w-full h-64 object-cover rounded-lg mb-4"
                />
                <h3 className="text-lg font-semibold charcoal mb-2">Scenario</h3>
                <p className="text-charcoal/80 mb-4">{selectedChallenge.scenario}</p>
              </div>

              <div>
                <h3 className="text-lg font-semibold charcoal mb-4">Target Settings</h3>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="bg-light-grey rounded-lg p-3 text-center">
                    <div className="font-semibold charcoal text-sm">ISO</div>
                    <div className="lens-blue font-bold">{selectedChallenge.targetSettings.iso}</div>
                  </div>
                  <div className="bg-light-grey rounded-lg p-3 text-center">
                    <div className="font-semibold charcoal text-sm">Aperture</div>
                    <div className="lens-blue font-bold">f/{selectedChallenge.targetSettings.aperture}</div>
                  </div>
                  <div className="bg-light-grey rounded-lg p-3 text-center">
                    <div className="font-semibold charcoal text-sm">Shutter</div>
                    <div className="lens-blue font-bold">1/{selectedChallenge.targetSettings.shutterSpeed}s</div>
                  </div>
                  <div className="bg-light-grey rounded-lg p-3 text-center">
                    <div className="font-semibold charcoal text-sm">WB</div>
                    <div className="lens-blue font-bold">{selectedChallenge.targetSettings.whiteBalance}K</div>
                  </div>
                </div>

                <h3 className="text-lg font-semibold charcoal mb-3">Tips</h3>
                <ul className="space-y-2 mb-6">
                  {selectedChallenge.tips.map((tip, index) => (
                    <li key={index} className="flex items-start text-sm text-charcoal/80">
                      <Target className="h-4 w-4 warm-orange mr-2 mt-0.5 flex-shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button onClick={resetChallenge} variant="outline">
                Back to Challenges
              </Button>
              <Button className="bg-focus-green text-white hover:bg-focus-green/90">
                <CheckCircle className="h-4 w-4 mr-2" />
                Complete Challenge
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-roboto font-bold charcoal">Practice Challenges</h2>
        <Button className="bg-focus-green text-white hover:bg-focus-green/90">
          <Play className="h-4 w-4 mr-2" />
          Start Challenge
        </Button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {challenges.map((challenge) => (
          <Card key={challenge.id} className="bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
            <img
              src={challenge.image}
              alt={challenge.title}
              className="w-full h-48 object-cover"
            />
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-roboto font-semibold charcoal">{challenge.title}</h3>
                <Badge className={`${challenge.difficultyColor} text-white text-xs`}>
                  {challenge.difficulty}
                </Badge>
              </div>
              <p className="text-sm text-charcoal/70 mb-4">{challenge.description}</p>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2 text-xs text-charcoal/60">
                  <Clock className="h-3 w-3" />
                  <span>{challenge.duration}</span>
                </div>
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-3 w-3 ${
                        i < challenge.stars 
                          ? "warm-orange fill-current" 
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </div>
              <Button 
                onClick={() => startChallenge(challenge)}
                className="w-full bg-focus-green text-white hover:bg-focus-green/90"
              >
                <Play className="h-4 w-4 mr-2" />
                Start Challenge
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
