export default function PhotoGallery() {
  const photos = [
    {
      src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Portrait sample"
    },
    {
      src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Landscape sample"
    },
    {
      src: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Night photography sample"
    },
    {
      src: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Camera equipment"
    }
  ];

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-roboto font-bold charcoal mb-6">Sample Photo Gallery</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {photos.map((photo, index) => (
          <img
            key={index}
            src={photo.src}
            alt={photo.alt}
            className="w-full h-32 object-cover rounded-lg hover:scale-105 transition-transform cursor-pointer"
          />
        ))}
      </div>
    </div>
  );
}
