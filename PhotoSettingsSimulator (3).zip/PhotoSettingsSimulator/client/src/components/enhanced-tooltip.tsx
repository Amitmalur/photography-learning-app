import { useState } from "react";
import { Info, Lightbulb, TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";

interface EnhancedTooltipProps {
  setting: string;
  value: number;
  title: string;
  description: string;
  tips: string[];
  effects: {
    visual: string;
    technical: string;
    creative: string;
  };
  ranges: {
    low: { range: string; description: string; use: string; };
    medium: { range: string; description: string; use: string; };
    high: { range: string; description: string; use: string; };
  };
  children: React.ReactNode;
}

export default function EnhancedTooltip({ 
  setting, 
  value, 
  title, 
  description, 
  tips, 
  effects, 
  ranges, 
  children 
}: EnhancedTooltipProps) {
  const [isOpen, setIsOpen] = useState(false);

  const getCurrentRange = () => {
    if (setting === 'iso') {
      if (value <= 400) return 'low';
      if (value <= 1600) return 'medium';
      return 'high';
    }
    if (setting === 'aperture') {
      if (value <= 2.8) return 'low';
      if (value <= 8) return 'medium';
      return 'high';
    }
    if (setting === 'shutterSpeed') {
      if (value >= 250) return 'high';
      if (value >= 60) return 'medium';
      return 'low';
    }
    if (setting === 'whiteBalance') {
      if (value <= 4000) return 'low';
      if (value <= 6500) return 'medium';
      return 'high';
    }
    if (setting === 'focus') {
      if (value <= 0.3) return 'low';
      if (value <= 0.7) return 'medium';
      return 'high';
    }
    return 'medium';
  };

  const currentRange = getCurrentRange();
  const currentRangeData = ranges[currentRange as keyof typeof ranges];

  const getEffectIcon = (effect: string) => {
    if (effect.includes('increase') || effect.includes('higher') || effect.includes('more')) {
      return <TrendingUp className="h-3 w-3 text-focus-green" />;
    }
    if (effect.includes('decrease') || effect.includes('lower') || effect.includes('less')) {
      return <TrendingDown className="h-3 w-3 text-warm-orange" />;
    }
    return <AlertCircle className="h-3 w-3 text-lens-blue" />;
  };

  return (
    <Tooltip open={isOpen} onOpenChange={setIsOpen}>
      <TooltipTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="p-0 h-auto lens-blue hover:text-lens-blue/80"
          onClick={() => setIsOpen(!isOpen)}
        >
          {children}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="left" className="max-w-md p-0 bg-white shadow-lg border border-gray-200">
        <div className="p-4">
          {/* Header */}
          <div className="flex items-center space-x-2 mb-3">
            <Info className="h-4 w-4 lens-blue" />
            <h3 className="font-semibold text-charcoal">{title}</h3>
          </div>

          {/* Description */}
          <p className="text-sm text-charcoal/80 mb-4">{description}</p>

          {/* Current Value & Range */}
          <div className="bg-light-grey rounded-lg p-3 mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-charcoal">Current Value:</span>
              <span className="font-bold text-lens-blue">
                {setting === 'aperture' && `f/${value}`}
                {setting === 'shutterSpeed' && `1/${value}s`}
                {setting === 'whiteBalance' && `${value}K`}
                {setting === 'focus' && `${Math.round(value * 100)}%`}
                {setting === 'iso' && value}
              </span>
            </div>
            <div className="text-xs text-charcoal/60">
              <strong>{currentRangeData.range}</strong> - {currentRangeData.description}
            </div>
          </div>

          {/* Effects */}
          <div className="mb-4">
            <h4 className="text-sm font-medium text-charcoal mb-2 flex items-center">
              <Lightbulb className="h-3 w-3 warm-orange mr-1" />
              Effects of This Setting
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-start space-x-2">
                {getEffectIcon(effects.visual)}
                <div>
                  <span className="font-medium">Visual:</span> {effects.visual}
                </div>
              </div>
              <div className="flex items-start space-x-2">
                {getEffectIcon(effects.technical)}
                <div>
                  <span className="font-medium">Technical:</span> {effects.technical}
                </div>
              </div>
              <div className="flex items-start space-x-2">
                {getEffectIcon(effects.creative)}
                <div>
                  <span className="font-medium">Creative:</span> {effects.creative}
                </div>
              </div>
            </div>
          </div>

          {/* Range Guide */}
          <div className="mb-4">
            <h4 className="text-sm font-medium text-charcoal mb-2">Usage Guide</h4>
            <div className="space-y-2 text-xs">
              {Object.entries(ranges).map(([key, range]) => (
                <div 
                  key={key}
                  className={`p-2 rounded ${currentRange === key ? 'bg-lens-blue/10 border border-lens-blue/20' : 'bg-gray-50'}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-charcoal">{range.range}</span>
                    {currentRange === key && <span className="text-xs text-lens-blue font-medium">Current</span>}
                  </div>
                  <div className="text-charcoal/70 mt-1">{range.use}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Tips */}
          <div>
            <h4 className="text-sm font-medium text-charcoal mb-2">Quick Tips</h4>
            <ul className="space-y-1 text-xs text-charcoal/70">
              {tips.map((tip, index) => (
                <li key={index} className="flex items-start">
                  <span className="w-1 h-1 bg-warm-orange rounded-full mt-2 mr-2 flex-shrink-0"></span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}