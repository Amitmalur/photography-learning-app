import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Play, Pause, RotateCcw, CheckCircle, Lightbulb, Target, Eye, Zap, Palette, Focus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  setting: keyof CameraSettings;
  targetValue: number;
  explanation: string;
  tips: string[];
  icon: React.ReactNode;
  visualEffect: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

interface CameraTutorialProps {
  settings: CameraSettings;
  onSettingChange: (setting: keyof CameraSettings, value: number) => void;
  onTutorialComplete?: () => void;
}

const tutorialSteps: TutorialStep[] = [
  {
    id: "iso-basics",
    title: "Understanding ISO",
    description: "ISO controls how sensitive your camera sensor is to light. Let's start with the basics.",
    setting: "iso",
    targetValue: 800,
    explanation: "ISO 800 is perfect for indoor photography without flash. Higher values let you shoot in darker conditions but add noise (grain) to your photos.",
    tips: [
      "Lower ISO = cleaner image quality",
      "Higher ISO = better low-light performance",
      "Start with ISO 100-400 in bright light",
      "Use ISO 800-1600 indoors"
    ],
    icon: <Lightbulb className="h-5 w-5" />,
    visualEffect: "Watch how the image becomes brighter but also more grainy",
    difficulty: 'beginner'
  },
  {
    id: "aperture-depth",
    title: "Aperture and Depth of Field",
    description: "Aperture controls how much of your photo is in sharp focus. This is called depth of field.",
    setting: "aperture",
    targetValue: 2.8,
    explanation: "f/2.8 creates a shallow depth of field, perfect for portraits. The background becomes beautifully blurred while your subject stays sharp.",
    tips: [
      "Lower f-number = more background blur",
      "Higher f-number = more in focus",
      "f/1.4-f/2.8 for portraits",
      "f/8-f/11 for landscapes"
    ],
    icon: <Eye className="h-5 w-5" />,
    visualEffect: "Notice how the background becomes blurred and the subject stands out",
    difficulty: 'beginner'
  },
  {
    id: "shutter-motion",
    title: "Shutter Speed and Motion",
    description: "Shutter speed determines how motion appears in your photos - frozen or blurred.",
    setting: "shutterSpeed",
    targetValue: 250,
    explanation: "1/250s is fast enough to freeze most human movement. This speed prevents camera shake and captures sharp, crisp images.",
    tips: [
      "Fast speeds freeze motion",
      "Slow speeds create motion blur",
      "Use 1/focal length rule for handheld shots",
      "1/250s+ for sports and action"
    ],
    icon: <Zap className="h-5 w-5" />,
    visualEffect: "Fast shutter speeds eliminate motion blur and camera shake",
    difficulty: 'beginner'
  },
  {
    id: "white-balance-color",
    title: "White Balance and Color",
    description: "White balance ensures colors look natural under different lighting conditions.",
    setting: "whiteBalance",
    targetValue: 5600,
    explanation: "5600K matches daylight conditions, giving you natural-looking colors. Different light sources have different color temperatures.",
    tips: [
      "3200K for tungsten/indoor lighting",
      "5600K for daylight",
      "6500K for shade",
      "Auto WB works well most of the time"
    ],
    icon: <Palette className="h-5 w-5" />,
    visualEffect: "Color temperature affects the warmth or coolness of your image",
    difficulty: 'intermediate'
  },
  {
    id: "focus-control",
    title: "Focus Control",
    description: "Focus determines which part of your image is sharp. This works with aperture to control depth of field.",
    setting: "focus",
    targetValue: 0.7,
    explanation: "70% focus is ideal for portraits - focusing on the subject while allowing background elements to fall into pleasant blur.",
    tips: [
      "Focus on the most important part of your image",
      "For portraits, focus on the eyes",
      "Use single-point autofocus for precision",
      "Back-button focus gives you more control"
    ],
    icon: <Focus className="h-5 w-5" />,
    visualEffect: "Focus determines the sharp area of your image",
    difficulty: 'intermediate'
  },
  {
    id: "exposure-triangle",
    title: "The Exposure Triangle",
    description: "Now let's see how ISO, aperture, and shutter speed work together to control exposure.",
    setting: "iso",
    targetValue: 400,
    explanation: "The exposure triangle shows how changing one setting affects the others. Understanding this relationship is key to creative photography.",
    tips: [
      "ISO + Aperture + Shutter Speed = Exposure",
      "Change one, adjust others to compensate",
      "Each setting has creative effects beyond exposure",
      "Practice balancing all three settings"
    ],
    icon: <Target className="h-5 w-5" />,
    visualEffect: "All settings work together to create the final exposure",
    difficulty: 'advanced'
  }
];

export default function CameraTutorial({ settings, onSettingChange, onTutorialComplete }: CameraTutorialProps) {
  const [isActive, setIsActive] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasCompletedStep, setHasCompletedStep] = useState<boolean[]>(new Array(tutorialSteps.length).fill(false));
  const [showHint, setShowHint] = useState(false);

  const currentTutorialStep = tutorialSteps[currentStep];
  const progress = ((currentStep + 1) / tutorialSteps.length) * 100;
  const completedSteps = hasCompletedStep.filter(Boolean).length;

  useEffect(() => {
    if (isPlaying && isActive) {
      const timer = setTimeout(() => {
        if (currentStep < tutorialSteps.length - 1) {
          nextStep();
        } else {
          setIsPlaying(false);
          if (onTutorialComplete) {
            onTutorialComplete();
          }
        }
      }, 8000);

      return () => clearTimeout(timer);
    }
  }, [isPlaying, currentStep, isActive]);

  useEffect(() => {
    if (isActive) {
      const step = tutorialSteps[currentStep];
      const currentValue = settings[step.setting];
      const targetValue = step.targetValue;
      const tolerance = step.setting === 'focus' ? 0.1 : (step.setting === 'whiteBalance' ? 200 : step.targetValue * 0.1);
      
      if (Math.abs(currentValue - targetValue) <= tolerance) {
        setHasCompletedStep(prev => {
          const newState = [...prev];
          newState[currentStep] = true;
          return newState;
        });
      }
    }
  }, [settings, currentStep, isActive]);

  const startTutorial = () => {
    setIsActive(true);
    setCurrentStep(0);
    setHasCompletedStep(new Array(tutorialSteps.length).fill(false));
    setShowHint(false);
  };

  const exitTutorial = () => {
    setIsActive(false);
    setIsPlaying(false);
    setCurrentStep(0);
  };

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
      setShowHint(false);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      setShowHint(false);
    }
  };

  const adjustToTarget = () => {
    const step = tutorialSteps[currentStep];
    onSettingChange(step.setting, step.targetValue);
  };

  const toggleAutoPlay = () => {
    setIsPlaying(!isPlaying);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-focus-green';
      case 'intermediate': return 'bg-lens-blue';
      case 'advanced': return 'bg-warm-orange';
      default: return 'bg-gray-500';
    }
  };

  if (!isActive) {
    return (
      <Card className="bg-gradient-to-r from-lens-blue to-camera-dark text-white shadow-lg">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl font-roboto font-bold mb-2">Interactive Camera Tutorial</h2>
              <p className="text-blue-100">Learn camera settings step-by-step with guided practice and real-time feedback.</p>
              <div className="flex items-center space-x-4 mt-3 text-sm">
                <span className="flex items-center"><Target className="h-4 w-4 mr-1" /> 6 Interactive Lessons</span>
                <span className="flex items-center"><Lightbulb className="h-4 w-4 mr-1" /> Real-time Guidance</span>
                <span className="flex items-center"><CheckCircle className="h-4 w-4 mr-1" /> Progress Tracking</span>
              </div>
            </div>
            <div className="flex flex-col items-center space-y-3">
              <Button 
                onClick={startTutorial}
                className="bg-white text-lens-blue px-8 py-3 font-semibold hover:bg-gray-50"
              >
                <Play className="h-4 w-4 mr-2" />
                Start Tutorial
              </Button>
              <span className="text-xs text-blue-200">15-20 minutes • Beginner friendly</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Tutorial Header */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                {currentTutorialStep.icon}
                <h2 className="text-xl font-roboto font-bold charcoal">Camera Tutorial</h2>
              </div>
              <Badge className={`${getDifficultyColor(currentTutorialStep.difficulty)} text-white text-xs`}>
                {currentTutorialStep.difficulty}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-charcoal/70">
                Step {currentStep + 1} of {tutorialSteps.length}
              </span>
              <Button onClick={exitTutorial} variant="outline" size="sm">
                Exit Tutorial
              </Button>
            </div>
          </div>
          
          <Progress value={progress} className="h-2 mb-4" />
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-charcoal/70">
              {completedSteps} of {tutorialSteps.length} steps completed
            </span>
            <div className="flex items-center space-x-2">
              <Button
                onClick={toggleAutoPlay}
                variant="outline"
                size="sm"
                className="text-xs"
              >
                {isPlaying ? <Pause className="h-3 w-3 mr-1" /> : <Play className="h-3 w-3 mr-1" />}
                {isPlaying ? 'Pause' : 'Auto Play'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current Step Content */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Instruction Panel */}
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-lens-blue rounded-lg text-white">
                  {currentTutorialStep.icon}
                </div>
                <div>
                  <h3 className="text-lg font-roboto font-bold charcoal">
                    {currentTutorialStep.title}
                  </h3>
                  <p className="text-sm text-charcoal/70">
                    {currentTutorialStep.description}
                  </p>
                </div>
              </div>

              <div className="bg-light-grey rounded-lg p-4 mb-6">
                <p className="text-charcoal/80 mb-3">{currentTutorialStep.explanation}</p>
                <div className="text-sm text-lens-blue font-medium">
                  {currentTutorialStep.visualEffect}
                </div>
              </div>

              {/* Target Value */}
              <div className="bg-gradient-to-r from-focus-green to-focus-green/80 rounded-lg p-4 text-white mb-6">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Target Setting:</span>
                  <div className="text-lg font-bold">
                    {currentTutorialStep.setting === 'aperture' && `f/${currentTutorialStep.targetValue}`}
                    {currentTutorialStep.setting === 'shutterSpeed' && `1/${currentTutorialStep.targetValue}s`}
                    {currentTutorialStep.setting === 'whiteBalance' && `${currentTutorialStep.targetValue}K`}
                    {currentTutorialStep.setting === 'focus' && `${Math.round(currentTutorialStep.targetValue * 100)}%`}
                    {currentTutorialStep.setting === 'iso' && currentTutorialStep.targetValue}
                  </div>
                </div>
                <div className="text-sm opacity-90 mt-1">
                  Adjust the {currentTutorialStep.setting} control to match this value
                </div>
              </div>

              {/* Tips */}
              <div>
                <h4 className="font-semibold charcoal mb-3 flex items-center">
                  <Lightbulb className="h-4 w-4 warm-orange mr-2" />
                  Pro Tips
                </h4>
                <ul className="space-y-2">
                  {currentTutorialStep.tips.map((tip, index) => (
                    <li key={index} className="flex items-start text-sm text-charcoal/80">
                      <span className="w-2 h-2 bg-warm-orange rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Progress Panel */}
            <div>
              <div className="bg-light-grey rounded-lg p-6">
                <h4 className="font-semibold charcoal mb-4">Your Progress</h4>
                
                {/* Current Setting Value */}
                <div className="bg-white rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium charcoal">Current {currentTutorialStep.setting}:</span>
                    <span className="text-lg font-bold lens-blue">
                      {currentTutorialStep.setting === 'aperture' && `f/${settings.aperture}`}
                      {currentTutorialStep.setting === 'shutterSpeed' && `1/${settings.shutterSpeed}s`}
                      {currentTutorialStep.setting === 'whiteBalance' && `${settings.whiteBalance}K`}
                      {currentTutorialStep.setting === 'focus' && `${Math.round(settings.focus * 100)}%`}
                      {currentTutorialStep.setting === 'iso' && settings.iso}
                    </span>
                  </div>
                  
                  {/* Completion Status */}
                  {hasCompletedStep[currentStep] ? (
                    <div className="flex items-center text-focus-green text-sm font-medium">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Perfect! You've got it right.
                    </div>
                  ) : (
                    <div className="text-warm-orange text-sm">
                      Adjust the control to reach the target value
                    </div>
                  )}
                </div>

                {/* Quick Actions */}
                <div className="space-y-3">
                  <Button
                    onClick={adjustToTarget}
                    variant="outline"
                    className="w-full"
                  >
                    <Target className="h-4 w-4 mr-2" />
                    Set to Target Value
                  </Button>
                  
                  <Button
                    onClick={() => setShowHint(!showHint)}
                    variant="outline"
                    className="w-full"
                  >
                    <Lightbulb className="h-4 w-4 mr-2" />
                    {showHint ? 'Hide Hint' : 'Show Hint'}
                  </Button>

                  {showHint && (
                    <div className="bg-warm-orange/10 border border-warm-orange/20 rounded-lg p-3 text-sm text-charcoal/80">
                      Try moving the {currentTutorialStep.setting} slider slowly and watch how it affects the image preview. 
                      The goal is to understand the visual impact, not just hit the number.
                    </div>
                  )}
                </div>

                {/* Step Overview */}
                <div className="mt-6 pt-4 border-t border-gray-200">
                  <h5 className="font-medium charcoal mb-3">Tutorial Steps</h5>
                  <div className="space-y-2">
                    {tutorialSteps.map((step, index) => (
                      <div 
                        key={step.id}
                        className={`flex items-center text-sm p-2 rounded ${
                          index === currentStep 
                            ? 'bg-lens-blue text-white' 
                            : hasCompletedStep[index]
                            ? 'bg-focus-green/10 text-focus-green'
                            : 'text-charcoal/60'
                        }`}
                      >
                        <span className="mr-2">
                          {hasCompletedStep[index] ? (
                            <CheckCircle className="h-3 w-3" />
                          ) : index === currentStep ? (
                            <Play className="h-3 w-3" />
                          ) : (
                            <div className="w-3 h-3 border border-current rounded-full"></div>
                          )}
                        </span>
                        {step.title}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
            <Button
              onClick={prevStep}
              disabled={currentStep === 0}
              variant="outline"
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            <div className="flex items-center space-x-2">
              <Button
                onClick={() => {
                  setCurrentStep(0);
                  setHasCompletedStep(new Array(tutorialSteps.length).fill(false));
                }}
                variant="outline"
                size="sm"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Restart
              </Button>
            </div>

            <Button
              onClick={nextStep}
              disabled={currentStep === tutorialSteps.length - 1}
              className="bg-lens-blue text-white hover:bg-lens-blue/90"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}