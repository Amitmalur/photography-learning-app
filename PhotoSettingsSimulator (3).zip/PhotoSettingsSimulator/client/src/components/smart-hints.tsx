import { useState, useEffect } from "react";
import { Lightbulb, X, TrendingUp, AlertTriangle, CheckCircle, Eye, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface SmartHint {
  id: string;
  type: 'tip' | 'warning' | 'suggestion';
  title: string;
  message: string;
  icon: React.ReactNode;
  priority: number;
  actionable?: {
    text: string;
    action: () => void;
  };
}

interface SmartHintsProps {
  settings: CameraSettings;
  onSettingChange: (setting: keyof CameraSettings, value: number) => void;
}

export default function SmartHints({ settings, onSettingChange }: SmartHintsProps) {
  const [hints, setHints] = useState<SmartHint[]>([]);
  const [dismissedHints, setDismissedHints] = useState<Set<string>>(new Set());
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const generateHints = (): SmartHint[] => {
      const newHints: SmartHint[] = [];

      // ISO Analysis
      if (settings.iso >= 3200) {
        newHints.push({
          id: 'high-iso-warning',
          type: 'warning',
          title: 'High ISO Detected',
          message: 'ISO 3200+ will add significant noise. Consider using wider aperture or slower shutter speed if possible.',
          icon: <AlertTriangle className="h-4 w-4" />,
          priority: 8,
          actionable: {
            text: 'Lower to ISO 1600',
            action: () => onSettingChange('iso', 1600)
          }
        });
      } else if (settings.iso <= 200 && settings.aperture > 8) {
        newHints.push({
          id: 'low-iso-suggestion',
          type: 'suggestion',
          title: 'Excellent Image Quality',
          message: 'Low ISO with narrow aperture gives maximum sharpness. Perfect for landscapes!',
          icon: <CheckCircle className="h-4 w-4" />,
          priority: 3
        });
      }

      // Aperture Analysis
      if (settings.aperture <= 2.0 && settings.focus > 0.8) {
        newHints.push({
          id: 'portrait-setup',
          type: 'tip',
          title: 'Great for Portraits',
          message: 'Wide aperture with distant focus creates beautiful background blur. Try focusing closer for stronger effect.',
          icon: <Eye className="h-4 w-4" />,
          priority: 6,
          actionable: {
            text: 'Focus closer',
            action: () => onSettingChange('focus', 0.6)
          }
        });
      }

      if (settings.aperture >= 11) {
        newHints.push({
          id: 'diffraction-warning',
          type: 'warning',
          title: 'Diffraction Alert',
          message: 'f/11+ may reduce sharpness due to diffraction. f/8-f/11 is usually the sweet spot.',
          icon: <AlertTriangle className="h-4 w-4" />,
          priority: 7,
          actionable: {
            text: 'Try f/8',
            action: () => onSettingChange('aperture', 8.0)
          }
        });
      }

      // Shutter Speed Analysis
      if (settings.shutterSpeed <= 60 && settings.iso <= 400) {
        newHints.push({
          id: 'camera-shake-warning',
          type: 'warning',
          title: 'Camera Shake Risk',
          message: 'Slow shutter with low ISO risks camera shake. Use tripod or increase ISO.',
          icon: <Zap className="h-4 w-4" />,
          priority: 9,
          actionable: {
            text: 'Increase ISO',
            action: () => onSettingChange('iso', 800)
          }
        });
      }

      // Exposure Triangle Analysis
      const ev = Math.log2((settings.aperture * settings.aperture) / (1/settings.shutterSpeed)) - Math.log2(settings.iso / 100);
      if (ev < -2) {
        newHints.push({
          id: 'underexposed',
          type: 'warning',
          title: 'May Be Underexposed',
          message: 'Current settings might result in a dark image. Consider adjusting exposure settings.',
          icon: <TrendingUp className="h-4 w-4" />,
          priority: 8
        });
      } else if (ev > 2) {
        newHints.push({
          id: 'overexposed',
          type: 'warning',
          title: 'May Be Overexposed',
          message: 'Current settings might result in a bright image. Consider reducing exposure.',
          icon: <AlertTriangle className="h-4 w-4" />,
          priority: 8
        });
      }

      // White Balance Context
      if (settings.whiteBalance <= 3200 && settings.iso >= 1600) {
        newHints.push({
          id: 'indoor-lighting',
          type: 'tip',
          title: 'Indoor Lighting Setup',
          message: 'Warm white balance with high ISO suggests indoor/tungsten lighting. Good for cozy atmosphere!',
          icon: <Lightbulb className="h-4 w-4" />,
          priority: 4
        });
      }

      // Beginner Tips
      if (settings.aperture <= 2.8 && settings.shutterSpeed >= 250 && settings.iso <= 800) {
        newHints.push({
          id: 'good-settings',
          type: 'tip',
          title: 'Excellent Settings!',
          message: 'Great combination for sharp portraits with background blur. This is a solid baseline setup.',
          icon: <CheckCircle className="h-4 w-4" />,
          priority: 2
        });
      }

      // Creative Suggestions
      if (settings.shutterSpeed <= 30) {
        newHints.push({
          id: 'motion-blur-creative',
          type: 'suggestion',
          title: 'Creative Motion Blur',
          message: 'Slow shutter speed can create artistic motion effects. Try panning with moving subjects!',
          icon: <Zap className="h-4 w-4" />,
          priority: 5
        });
      }

      return newHints
        .filter(hint => !dismissedHints.has(hint.id))
        .sort((a, b) => b.priority - a.priority)
        .slice(0, 3); // Show max 3 hints
    };

    setHints(generateHints());
  }, [settings, dismissedHints, onSettingChange]);

  const dismissHint = (hintId: string) => {
    setDismissedHints(prev => {
      const newSet = new Set(prev);
      newSet.add(hintId);
      return newSet;
    });
  };

  const getHintColor = (type: SmartHint['type']) => {
    switch (type) {
      case 'warning': return 'border-warm-orange bg-warm-orange/5';
      case 'tip': return 'border-lens-blue bg-lens-blue/5';
      case 'suggestion': return 'border-focus-green bg-focus-green/5';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const getHintBadgeColor = (type: SmartHint['type']) => {
    switch (type) {
      case 'warning': return 'bg-warm-orange';
      case 'tip': return 'bg-lens-blue';
      case 'suggestion': return 'bg-focus-green';
      default: return 'bg-gray-500';
    }
  };

  if (!isVisible || hints.length === 0) {
    return (
      <Button
        onClick={() => setIsVisible(true)}
        variant="outline"
        size="sm"
        className="fixed bottom-4 right-4 bg-lens-blue text-white hover:bg-lens-blue/90 shadow-lg z-50"
      >
        <Lightbulb className="h-4 w-4 mr-2" />
        Smart Hints ({hints.length})
      </Button>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 w-80 space-y-3 z-50">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-charcoal">Smart Photography Hints</h3>
        <Button
          onClick={() => setIsVisible(false)}
          variant="ghost"
          size="sm"
          className="h-auto p-1"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {hints.map((hint) => (
        <Card key={hint.id} className={`shadow-lg border-2 ${getHintColor(hint.type)}`}>
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                <div className="text-charcoal">
                  {hint.icon}
                </div>
                <Badge className={`${getHintBadgeColor(hint.type)} text-white text-xs`}>
                  {hint.type}
                </Badge>
              </div>
              <Button
                onClick={() => dismissHint(hint.id)}
                variant="ghost"
                size="sm"
                className="h-auto p-1 text-charcoal/40 hover:text-charcoal"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>

            <h4 className="font-semibold text-charcoal text-sm mb-1">
              {hint.title}
            </h4>
            <p className="text-xs text-charcoal/80 mb-3">
              {hint.message}
            </p>

            {hint.actionable && (
              <Button
                onClick={() => {
                  hint.actionable!.action();
                  dismissHint(hint.id);
                }}
                size="sm"
                className="w-full bg-lens-blue text-white hover:bg-lens-blue/90 text-xs"
              >
                {hint.actionable.text}
              </Button>
            )}
          </CardContent>
        </Card>
      ))}

      <div className="text-center">
        <Button
          onClick={() => setDismissedHints(new Set())}
          variant="outline"
          size="sm"
          className="text-xs bg-white/90 backdrop-blur"
        >
          Reset All Hints
        </Button>
      </div>
    </div>
  );
}