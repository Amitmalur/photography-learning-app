import { useState, useEffect } from "react";
import { Trophy, Star, Target, BookOpen, CheckCircle, Lock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface LearningModule {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  completed: boolean;
  unlocked: boolean;
  progress: number;
  skills: string[];
  icon: React.ReactNode;
  requiredSettings?: Partial<CameraSettings>;
}

interface LearningProgressProps {
  settings: CameraSettings;
  onModuleSelect: (moduleId: string) => void;
  onSettingChange: (setting: keyof CameraSettings, value: number) => void;
}

export default function LearningProgress({ settings, onModuleSelect, onSettingChange }: LearningProgressProps) {
  const [modules, setModules] = useState<LearningModule[]>([
    {
      id: 'iso-basics',
      title: 'ISO Fundamentals',
      description: 'Master sensor sensitivity and noise control',
      difficulty: 'beginner',
      completed: false,
      unlocked: true,
      progress: 0,
      skills: ['Light sensitivity', 'Noise management', 'Quality balance'],
      icon: <Star className="h-5 w-5" />,
      requiredSettings: { iso: 400 }
    },
    {
      id: 'aperture-depth',
      title: 'Aperture & Depth of Field',
      description: 'Create stunning background blur and sharp landscapes',
      difficulty: 'beginner',
      completed: false,
      unlocked: true,
      progress: 0,
      skills: ['Depth control', 'Subject isolation', 'Sharpness zones'],
      icon: <Target className="h-5 w-5" />,
      requiredSettings: { aperture: 2.8 }
    },
    {
      id: 'shutter-motion',
      title: 'Shutter Speed & Motion',
      description: 'Freeze action or create artistic motion blur',
      difficulty: 'intermediate',
      completed: false,
      unlocked: false,
      progress: 0,
      skills: ['Motion control', 'Action freezing', 'Creative blur'],
      icon: <Trophy className="h-5 w-5" />,
      requiredSettings: { shutterSpeed: 125 }
    },
    {
      id: 'exposure-triangle',
      title: 'The Exposure Triangle',
      description: 'Balance ISO, aperture, and shutter speed perfectly',
      difficulty: 'intermediate',
      completed: false,
      unlocked: false,
      progress: 0,
      skills: ['Exposure balance', 'Creative control', 'Technical mastery'],
      icon: <BookOpen className="h-5 w-5" />
    },
    {
      id: 'advanced-techniques',
      title: 'Advanced Photography',
      description: 'Master professional techniques and creative vision',
      difficulty: 'advanced',
      completed: false,
      unlocked: false,
      progress: 0,
      skills: ['Professional workflow', 'Creative vision', 'Technical excellence'],
      icon: <Trophy className="h-5 w-5" />
    }
  ]);

  const [userStats, setUserStats] = useState({
    totalXP: 0,
    level: 1,
    streak: 0,
    modulesCompleted: 0,
    skillsUnlocked: 0
  });

  useEffect(() => {
    // Check module completion based on current settings and interactions
    setModules(prevModules => {
      return prevModules.map(module => {
        let newProgress = module.progress;
        let completed = module.completed;

        // Check if current settings match module requirements
        if (module.requiredSettings) {
          const settingsMatch = Object.entries(module.requiredSettings).every(([key, value]) => {
            const currentValue = settings[key as keyof CameraSettings];
            if (typeof value === 'number') {
              return Math.abs(currentValue - value) <= (value * 0.2); // 20% tolerance
            }
            return true;
          });

          if (settingsMatch && !completed) {
            newProgress = Math.min(100, newProgress + 10);
            if (newProgress >= 100) {
              completed = true;
            }
          }
        }

        return { ...module, progress: newProgress, completed };
      });
    });
  }, [settings]);

  useEffect(() => {
    // Update unlock status based on previous modules
    setModules(prevModules => {
      return prevModules.map((module, index) => {
        if (index === 0) return module; // First module always unlocked
        
        const previousModule = prevModules[index - 1];
        const unlocked = previousModule.completed || module.unlocked;
        
        return { ...module, unlocked };
      });
    });

    // Update user stats
    const completedCount = modules.filter(m => m.completed).length;
    const totalSkills = modules.reduce((acc, m) => acc + m.skills.length, 0);
    
    setUserStats(prev => ({
      ...prev,
      modulesCompleted: completedCount,
      skillsUnlocked: completedCount * 3, // Approximate skills per module
      level: Math.floor(completedCount / 2) + 1,
      totalXP: completedCount * 100
    }));
  }, [modules]);

  const getDifficultyColor = (difficulty: LearningModule['difficulty']) => {
    switch (difficulty) {
      case 'beginner': return 'bg-focus-green text-white';
      case 'intermediate': return 'bg-warm-orange text-white';
      case 'advanced': return 'bg-red-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const practiceModule = (module: LearningModule) => {
    if (module.requiredSettings) {
      Object.entries(module.requiredSettings).forEach(([key, value]) => {
        if (typeof value === 'number') {
          onSettingChange(key as keyof CameraSettings, value);
        }
      });
    }
    onModuleSelect(module.id);
  };

  return (
    <div className="space-y-6">
      {/* User Stats Header */}
      <Card className="bg-gradient-to-r from-lens-blue to-focus-green text-white">
        <CardContent className="p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{userStats.level}</div>
              <div className="text-sm opacity-90">Level</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{userStats.totalXP}</div>
              <div className="text-sm opacity-90">XP</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{userStats.modulesCompleted}</div>
              <div className="text-sm opacity-90">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{userStats.skillsUnlocked}</div>
              <div className="text-sm opacity-90">Skills</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Learning Modules */}
      <div className="grid gap-4">
        <h3 className="text-xl font-semibold text-charcoal mb-4">Learning Path</h3>
        
        {modules.map((module, index) => (
          <Card 
            key={module.id} 
            className={`relative overflow-hidden transition-all hover:shadow-lg ${
              !module.unlocked ? 'opacity-50' : ''
            } ${module.completed ? 'border-focus-green bg-focus-green/5' : ''}`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-lg ${
                    module.completed ? 'bg-focus-green text-white' : 
                    module.unlocked ? 'bg-lens-blue text-white' : 'bg-gray-300 text-gray-500'
                  }`}>
                    {module.completed ? <CheckCircle className="h-5 w-5" /> : 
                     module.unlocked ? module.icon : <Lock className="h-5 w-5" />}
                  </div>
                  <div>
                    <CardTitle className="text-lg text-charcoal">{module.title}</CardTitle>
                    <p className="text-sm text-charcoal/70 mt-1">{module.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge className={getDifficultyColor(module.difficulty)}>
                    {module.difficulty}
                  </Badge>
                  {module.completed && (
                    <Badge className="bg-focus-green text-white">
                      ✓ Complete
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-charcoal/70 mb-1">
                  <span>Progress</span>
                  <span>{module.progress}%</span>
                </div>
                <Progress value={module.progress} className="h-2" />
              </div>

              {/* Skills */}
              <div className="mb-4">
                <p className="text-sm font-medium text-charcoal mb-2">Skills you'll learn:</p>
                <div className="flex flex-wrap gap-2">
                  {module.skills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <Button
                onClick={() => practiceModule(module)}
                disabled={!module.unlocked}
                className={`w-full ${
                  module.completed ? 'bg-focus-green hover:bg-focus-green/90' :
                  module.unlocked ? 'bg-lens-blue hover:bg-lens-blue/90' : ''
                }`}
                variant={module.unlocked ? "default" : "secondary"}
              >
                {!module.unlocked ? 'Locked' :
                 module.completed ? 'Review' : 'Start Learning'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}