import { Info, Lightbulb, Eye, Zap, Palette, Focus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import EnhancedTooltip from "@/components/enhanced-tooltip";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface CameraControlsProps {
  settings: CameraSettings;
  onSettingChange: (setting: keyof CameraSettings, value: number) => void;
}

export default function CameraControls({ settings, onSettingChange }: CameraControlsProps) {
  const getISOTip = (iso: number) => {
    if (iso <= 200) return "Very low noise, excellent image quality. Best for bright conditions.";
    if (iso <= 800) return "Good balance of light sensitivity and image quality.";
    if (iso <= 1600) return "Moderate noise, suitable for indoor or low light conditions.";
    return "Higher noise but good for very low light situations.";
  };

  const getApertureTip = (aperture: number) => {
    if (aperture <= 2.0) return "Very shallow depth of field, strong background blur.";
    if (aperture <= 4.0) return "Moderate depth of field, good for portraits.";
    if (aperture <= 8.0) return "Good overall sharpness, suitable for landscapes.";
    return "Very deep depth of field, everything in focus.";
  };

  const getShutterTip = (shutter: number) => {
    if (shutter >= 500) return "Freezes fast motion, eliminates camera shake.";
    if (shutter >= 125) return "Good for general photography, minimal motion blur.";
    if (shutter >= 30) return "May show slight motion blur, use steady hands.";
    return "Long exposure, creates motion blur effects.";
  };

  const getWBTip = (wb: number) => {
    if (wb <= 3500) return "Very warm tone, orange/yellow cast.";
    if (wb <= 5000) return "Warm tone, suitable for indoor lighting.";
    if (wb <= 6500) return "Neutral white, good for daylight conditions.";
    return "Cool tone, blue cast for shade or overcast conditions.";
  };

  return (
    <div className="space-y-6">
      {/* ISO Control */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <h4 className="text-lg font-roboto font-semibold charcoal">ISO</h4>
              <EnhancedTooltip
                setting="iso"
                value={settings.iso}
                title="ISO Sensitivity"
                description="ISO controls how sensitive your camera sensor is to light. Higher values allow shooting in darker conditions but introduce noise (grain)."
                tips={[
                  "Use the lowest ISO possible for your lighting conditions",
                  "ISO 100-400 for bright outdoor conditions",
                  "ISO 800-1600 for indoor photography",
                  "ISO 3200+ for very low light situations"
                ]}
                effects={{
                  visual: "Higher ISO brightens the image but adds visible grain/noise",
                  technical: "Affects image quality and digital noise levels",
                  creative: "High ISO can add artistic grain for mood and atmosphere"
                }}
                ranges={{
                  low: { range: "100-400", description: "Clean, low noise", use: "Bright daylight, studio lighting" },
                  medium: { range: "800-1600", description: "Moderate noise", use: "Indoor, overcast conditions" },
                  high: { range: "3200+", description: "Visible noise", use: "Low light, night photography" }
                }}
              >
                <Info className="h-4 w-4" />
              </EnhancedTooltip>
            </div>
            <span className="text-sm bg-lens-blue text-white px-2 py-1 rounded-full">{settings.iso}</span>
          </div>

          <div className="mb-4">
            <Slider
              value={[settings.iso]}
              onValueChange={(value) => onSettingChange("iso", value[0])}
              min={100}
              max={6400}
              step={100}
              className="camera-slider"
            />
          </div>

          <div className="flex justify-between text-xs text-charcoal/70 mb-2">
            <span>100</span>
            <span>800</span>
            <span>1600</span>
            <span>3200</span>
            <span>6400</span>
          </div>

          <div className="bg-light-grey rounded-lg p-3 text-sm text-charcoal/80">
            <Lightbulb className="h-4 w-4 warm-orange inline mr-2" />
            <span>{getISOTip(settings.iso)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Aperture Control */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <h4 className="text-lg font-roboto font-semibold charcoal">Aperture</h4>
              <EnhancedTooltip
                setting="aperture"
                value={settings.aperture}
                title="Aperture & Depth of Field"
                description="Aperture controls how much light enters the camera and determines depth of field (how much of your image is in focus)."
                tips={[
                  "Lower f-numbers = wider aperture = more light + shallow focus",
                  "Higher f-numbers = narrower aperture = less light + deep focus",
                  "f/1.4-f/2.8 for portraits with background blur",
                  "f/8-f/11 for landscapes with everything in focus"
                ]}
                effects={{
                  visual: "Lower f-numbers create beautiful background blur (bokeh)",
                  technical: "Controls amount of light entering the camera",
                  creative: "Primary tool for isolating subjects and controlling focus"
                }}
                ranges={{
                  low: { range: "f/1.4-f/2.8", description: "Very shallow depth", use: "Portraits, subject isolation" },
                  medium: { range: "f/4-f/8", description: "Moderate depth", use: "General photography, groups" },
                  high: { range: "f/11-f/16", description: "Deep focus", use: "Landscapes, architecture" }
                }}
              >
                <Info className="h-4 w-4" />
              </EnhancedTooltip>
            </div>
            <span className="text-sm bg-lens-blue text-white px-2 py-1 rounded-full">f/{settings.aperture}</span>
          </div>

          <div className="mb-4">
            <Slider
              value={[settings.aperture]}
              onValueChange={(value) => onSettingChange("aperture", value[0])}
              min={1.4}
              max={16}
              step={0.1}
              className="camera-slider"
            />
          </div>

          <div className="flex justify-between text-xs text-charcoal/70 mb-2">
            <span>f/1.4</span>
            <span>f/2.8</span>
            <span>f/5.6</span>
            <span>f/8</span>
            <span>f/16</span>
          </div>

          <div className="bg-light-grey rounded-lg p-3 text-sm text-charcoal/80">
            <Eye className="h-4 w-4 warm-orange inline mr-2" />
            <span>{getApertureTip(settings.aperture)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Shutter Speed Control */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <h4 className="text-lg font-roboto font-semibold charcoal">Shutter Speed</h4>
              <EnhancedTooltip
                setting="shutterSpeed"
                value={settings.shutterSpeed}
                title="Shutter Speed & Motion"
                description="Shutter speed controls how long the camera sensor is exposed to light, affecting motion blur and camera shake."
                tips={[
                  "Fast speeds (1/250s+) freeze motion and prevent shake",
                  "Slow speeds create motion blur and require steady hands",
                  "Use 1/focal length rule for handheld shooting",
                  "Tripod recommended for speeds slower than 1/60s"
                ]}
                effects={{
                  visual: "Fast speeds freeze action, slow speeds create motion blur",
                  technical: "Controls exposure time and camera shake",
                  creative: "Motion blur can show movement and create dynamic effects"
                }}
                ranges={{
                  low: { range: "1s-1/30s", description: "Motion blur", use: "Creative effects, flowing water" },
                  medium: { range: "1/60s-1/125s", description: "General use", use: "Portraits, careful handheld" },
                  high: { range: "1/250s+", description: "Freeze motion", use: "Sports, action, wildlife" }
                }}
              >
                <Info className="h-4 w-4" />
              </EnhancedTooltip>
            </div>
            <span className="text-sm bg-lens-blue text-white px-2 py-1 rounded-full">1/{settings.shutterSpeed}s</span>
          </div>

          <div className="mb-4">
            <Slider
              value={[settings.shutterSpeed]}
              onValueChange={(value) => onSettingChange("shutterSpeed", value[0])}
              min={1}
              max={1000}
              step={1}
              className="camera-slider"
            />
          </div>

          <div className="flex justify-between text-xs text-charcoal/70 mb-2">
            <span>1s</span>
            <span>1/15s</span>
            <span>1/60s</span>
            <span>1/250s</span>
            <span>1/1000s</span>
          </div>

          <div className="bg-light-grey rounded-lg p-3 text-sm text-charcoal/80">
            <Zap className="h-4 w-4 warm-orange inline mr-2" />
            <span>{getShutterTip(settings.shutterSpeed)}</span>
          </div>
        </CardContent>
      </Card>

      {/* White Balance Control */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <h4 className="text-lg font-roboto font-semibold charcoal">White Balance</h4>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="p-0 h-auto lens-blue hover:text-lens-blue/80">
                    <Info className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>White balance affects color temperature</p>
                </TooltipContent>
              </Tooltip>
            </div>
            <span className="text-sm bg-lens-blue text-white px-2 py-1 rounded-full">{settings.whiteBalance}K</span>
          </div>

          <div className="mb-4">
            <Slider
              value={[settings.whiteBalance]}
              onValueChange={(value) => onSettingChange("whiteBalance", value[0])}
              min={2500}
              max={10000}
              step={100}
              className="camera-slider"
            />
          </div>

          <div className="flex justify-between text-xs text-charcoal/70 mb-2">
            <span className="warm-orange">2500K</span>
            <span>4000K</span>
            <span>5600K</span>
            <span>7000K</span>
            <span className="lens-blue">10000K</span>
          </div>

          <div className="bg-light-grey rounded-lg p-3 text-sm text-charcoal/80">
            <Palette className="h-4 w-4 warm-orange inline mr-2" />
            <span>{getWBTip(settings.whiteBalance)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Focus Control */}
      <Card className="bg-white shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <h4 className="text-lg font-roboto font-semibold charcoal">Focus</h4>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="p-0 h-auto lens-blue hover:text-lens-blue/80">
                    <Info className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Focus determines which part of the image is sharp</p>
                </TooltipContent>
              </Tooltip>
            </div>
            <span className="text-sm bg-lens-blue text-white px-2 py-1 rounded-full">{Math.round(settings.focus * 100)}%</span>
          </div>

          <div className="mb-4">
            <Slider
              value={[settings.focus]}
              onValueChange={(value) => onSettingChange("focus", value[0])}
              min={0}
              max={1}
              step={0.01}
              className="camera-slider"
            />
          </div>

          <div className="flex justify-between text-xs text-charcoal/70 mb-2">
            <span>Near</span>
            <span>Middle</span>
            <span>Far</span>
          </div>

          <div className="bg-light-grey rounded-lg p-3 text-sm text-charcoal/80">
            <Focus className="h-4 w-4 warm-orange inline mr-2" />
            <span>
              {settings.focus < 0.3 
                ? "Focus on foreground objects. Background will be blurred."
                : settings.focus < 0.7 
                ? "Focus on middle distance. Balanced depth of field."
                : "Focus on distant objects. Foreground may be slightly blurred."}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
