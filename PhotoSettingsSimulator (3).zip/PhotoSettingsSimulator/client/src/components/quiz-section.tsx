import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, RotateCcw } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "What happens when you increase the ISO setting?",
    options: [
      "The image becomes darker",
      "The sensor becomes more sensitive to light",
      "The depth of field increases",
      "The shutter speed automatically increases"
    ],
    correct: 1,
    explanation: "Higher ISO makes the sensor more sensitive to light, allowing shooting in darker conditions but adding more noise."
  },
  {
    id: 2,
    question: "For a portrait with blurred background, you should use:",
    options: [
      "A small aperture (f/16)",
      "A large aperture (f/1.8)",
      "A high ISO setting",
      "A slow shutter speed"
    ],
    correct: 1,
    explanation: "A large aperture (small f-number) creates shallow depth of field, blurring the background while keeping the subject sharp."
  },
  {
    id: 3,
    question: "To freeze fast motion, you need:",
    options: [
      "A slow shutter speed",
      "A fast shutter speed",
      "A low ISO",
      "A small aperture"
    ],
    correct: 1,
    explanation: "Fast shutter speeds (1/500s or faster) freeze motion by capturing the subject in a very short time frame."
  }
];

export default function QuizSection() {
  const [isQuizActive, setIsQuizActive] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const startQuiz = () => {
    setIsQuizActive(true);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setUserAnswers([]);
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const queryClient = useQueryClient();

  const saveQuizResult = useMutation({
    mutationFn: async (result: { quizType: string; score: number; totalQuestions: number }) => {
      // For demo purposes, using user ID 1. In a real app, you'd get this from authentication
      const userId = 1;
      const response = await fetch(`/api/users/${userId}/quiz-results`, {
        method: 'POST',
        body: JSON.stringify(result),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to save quiz result');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/quiz-results'] });
    },
  });

  const handleNextQuestion = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...userAnswers, selectedAnswer];
    setUserAnswers(newAnswers);

    const newScore = selectedAnswer === quizQuestions[currentQuestion].correct ? score + 1 : score;
    setScore(newScore);

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setShowResult(true);
      // Save quiz result to database
      saveQuizResult.mutate({
        quizType: 'photography-basics',
        score: newScore,
        totalQuestions: quizQuestions.length
      });
    }
  };

  const resetQuiz = () => {
    setIsQuizActive(false);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setUserAnswers([]);
  };

  if (!isQuizActive) {
    return (
      <div className="mt-12">
        <div className="bg-gradient-to-r from-lens-blue to-camera-dark rounded-xl p-8 text-white">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl font-roboto font-bold mb-2">Ready to Test Your Knowledge?</h2>
              <p className="text-blue-100">Take our interactive quiz to see how much you've learned!</p>
            </div>
            <div className="flex flex-col items-center space-y-2">
              <Button 
                onClick={startQuiz}
                className="bg-white text-lens-blue px-6 py-3 font-semibold hover:bg-gray-50"
              >
                Start Quiz
              </Button>
              <span className="text-xs text-blue-200">{quizQuestions.length} questions • 3 minutes</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showResult) {
    const percentage = Math.round((score / quizQuestions.length) * 100);
    return (
      <div className="mt-12">
        <Card className="bg-white shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              {percentage >= 70 ? (
                <CheckCircle className="h-16 w-16 focus-green mx-auto mb-4" />
              ) : (
                <XCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
              )}
              <h2 className="text-2xl font-roboto font-bold charcoal mb-2">Quiz Complete!</h2>
              <p className="text-lg lens-blue font-semibold">You scored {score} out of {quizQuestions.length} ({percentage}%)</p>
            </div>
            
            <div className="mb-6">
              <Progress value={percentage} className="h-3 mb-2" />
              <p className="text-sm text-charcoal/70">
                {percentage >= 70 ? "Great job! You've mastered the basics." : "Keep practicing to improve your photography knowledge!"}
              </p>
            </div>

            <div className="flex gap-4 justify-center">
              <Button onClick={resetQuiz} className="bg-lens-blue text-white hover:bg-lens-blue/90">
                <RotateCcw className="h-4 w-4 mr-2" />
                Try Again
              </Button>
              <Button onClick={() => setIsQuizActive(false)} variant="outline">
                Back to Learning
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const question = quizQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  return (
    <div className="mt-12">
      <Card className="bg-white shadow-lg">
        <CardContent className="p-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-roboto font-bold charcoal">Photography Quiz</h2>
              <span className="text-sm text-charcoal/70">
                Question {currentQuestion + 1} of {quizQuestions.length}
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-semibold charcoal mb-6">{question.question}</h3>
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-colors ${
                    selectedAnswer === index
                      ? "border-lens-blue bg-lens-blue/10 text-lens-blue"
                      : "border-light-grey hover:border-lens-blue/50 hover:bg-light-grey/50"
                  }`}
                >
                  <span className="font-medium">{String.fromCharCode(65 + index)}.</span> {option}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-between">
            <Button
              onClick={resetQuiz}
              variant="outline"
              className="text-charcoal/70"
            >
              Exit Quiz
            </Button>
            <Button
              onClick={handleNextQuestion}
              disabled={selectedAnswer === null}
              className="bg-lens-blue text-white hover:bg-lens-blue/90"
            >
              {currentQuestion === quizQuestions.length - 1 ? "Finish Quiz" : "Next Question"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
