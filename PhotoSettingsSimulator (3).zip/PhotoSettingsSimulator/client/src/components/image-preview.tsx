import { useEffect, useRef } from "react";
import { Eye, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { applyImageEffects } from "@/lib/image-effects";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface ImagePreviewProps {
  settings: CameraSettings;
}

export default function ImagePreview({ settings }: ImagePreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const baseImageRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const baseImage = baseImageRef.current;
    
    if (!canvas || !baseImage) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Apply effects when settings change
    applyImageEffects(ctx, baseImage, settings);
  }, [settings]);

  const handleImageLoad = () => {
    const canvas = canvasRef.current;
    const baseImage = baseImageRef.current;
    
    if (!canvas || !baseImage) return;

    canvas.width = baseImage.naturalWidth;
    canvas.height = baseImage.naturalHeight;
    
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    applyImageEffects(ctx, baseImage, settings);
  };

  const getExposureValue = (aperture: number, shutterSpeed: number, iso: number): string => {
    const ev = Math.log2((aperture * aperture) / (1/shutterSpeed)) - Math.log2(iso / 100);
    return ev.toFixed(1);
  };

  return (
    <Card className="bg-white shadow-lg">
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-roboto font-semibold charcoal">Live Preview</h3>
          <div className="flex items-center space-x-2">
            <Button size="sm" variant="outline" className="text-xs bg-lens-blue text-white hover:bg-lens-blue/90">
              <Eye className="h-3 w-3 mr-1" />
              Before/After
            </Button>
            <Button size="sm" variant="outline" className="text-xs bg-warm-orange text-white hover:bg-warm-orange/90">
              <Download className="h-3 w-3 mr-1" />
              Save
            </Button>
          </div>
        </div>

        {/* Canvas for image manipulation */}
        <div className="relative mb-4 bg-gray-100 rounded-lg overflow-hidden" style={{ aspectRatio: "4/3" }}>
          <img
            ref={baseImageRef}
            src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
            alt="Photography sample"
            className="hidden"
            onLoad={handleImageLoad}
            crossOrigin="anonymous"
          />
          <canvas
            ref={canvasRef}
            className="w-full h-full object-cover transition-camera"
          />
          
          {/* Focus indicator */}
          <div 
            className="absolute w-16 h-16 border-2 border-focus-green rounded-full opacity-0 transition-opacity duration-300"
            style={{
              top: "33%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              opacity: settings.focus > 0.7 ? 1 : 0
            }}
          />
        </div>

        {/* Camera Settings Display */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
          <div className="bg-light-grey rounded-lg p-3 text-center">
            <div className="font-semibold charcoal">ISO</div>
            <div className="lens-blue font-bold">{settings.iso}</div>
          </div>
          <div className="bg-light-grey rounded-lg p-3 text-center">
            <div className="font-semibold charcoal">Aperture</div>
            <div className="lens-blue font-bold">f/{settings.aperture}</div>
          </div>
          <div className="bg-light-grey rounded-lg p-3 text-center">
            <div className="font-semibold charcoal">Shutter</div>
            <div className="lens-blue font-bold">1/{settings.shutterSpeed}s</div>
          </div>
          <div className="bg-light-grey rounded-lg p-3 text-center">
            <div className="font-semibold charcoal">WB</div>
            <div className="lens-blue font-bold">{settings.whiteBalance}K</div>
          </div>
          <div className="bg-light-grey rounded-lg p-3 text-center">
            <div className="font-semibold charcoal">EV</div>
            <div className="lens-blue font-bold">{getExposureValue(settings.aperture, settings.shutterSpeed, settings.iso)}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
