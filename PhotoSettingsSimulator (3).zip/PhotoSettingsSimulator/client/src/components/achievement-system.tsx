import { useState, useEffect } from "react";
import { Trophy, Medal, Award, Target, Camera, Star, CheckCircle, Lock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { CameraSettings } from "@/hooks/use-camera-settings";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: 'technical' | 'creative' | 'learning' | 'mastery';
  difficulty: 'bronze' | 'silver' | 'gold' | 'platinum';
  points: number;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  requirements: string[];
  hint?: string;
}

interface AchievementSystemProps {
  settings: CameraSettings;
  userInteractions: {
    settingsChanged: number;
    tutorialCompleted: boolean;
    quizScore: number;
    practiceSessionsCompleted: number;
    hintsUsed: number;
  };
}

export default function AchievementSystem({ settings, userInteractions }: AchievementSystemProps) {
  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: 'first-steps',
      title: 'First Steps',
      description: 'Adjust your first camera setting',
      icon: <Camera className="h-5 w-5" />,
      category: 'learning',
      difficulty: 'bronze',
      points: 10,
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      requirements: ['Change any camera setting'],
      hint: 'Try moving any of the camera control sliders'
    },
    {
      id: 'iso-explorer',
      title: 'ISO Explorer',
      description: 'Test different ISO values from 100 to 3200',
      icon: <Star className="h-5 w-5" />,
      category: 'technical',
      difficulty: 'bronze',
      points: 25,
      unlocked: false,
      progress: 0,
      maxProgress: 5,
      requirements: ['Use ISO 100', 'Use ISO 400', 'Use ISO 800', 'Use ISO 1600', 'Use ISO 3200'],
      hint: 'Experiment with different ISO values to see their effects'
    },
    {
      id: 'aperture-artist',
      title: 'Aperture Artist',
      description: 'Master depth of field with different aperture settings',
      icon: <Target className="h-5 w-5" />,
      category: 'creative',
      difficulty: 'silver',
      points: 50,
      unlocked: false,
      progress: 0,
      maxProgress: 4,
      requirements: ['Use f/1.4', 'Use f/2.8', 'Use f/8', 'Use f/16'],
      hint: 'Try wide apertures for portraits and narrow for landscapes'
    },
    {
      id: 'shutter-speed-master',
      title: 'Shutter Speed Master',
      description: 'Control motion with various shutter speeds',
      icon: <Medal className="h-5 w-5" />,
      category: 'technical',
      difficulty: 'silver',
      points: 50,
      unlocked: false,
      progress: 0,
      maxProgress: 4,
      requirements: ['Use 1/1000s', 'Use 1/250s', 'Use 1/60s', 'Use 1/15s'],
      hint: 'Fast speeds freeze motion, slow speeds create blur'
    },
    {
      id: 'exposure-triangle-expert',
      title: 'Exposure Triangle Expert',
      description: 'Balance ISO, aperture, and shutter speed perfectly',
      icon: <Award className="h-5 w-5" />,
      category: 'mastery',
      difficulty: 'gold',
      points: 100,
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      requirements: ['Achieve perfect exposure balance'],
      hint: 'Find the sweet spot where all three settings work together'
    },
    {
      id: 'quiz-champion',
      title: 'Quiz Champion',
      description: 'Score 100% on the photography quiz',
      icon: <Trophy className="h-5 w-5" />,
      category: 'learning',
      difficulty: 'gold',
      points: 75,
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      requirements: ['Perfect quiz score'],
      hint: 'Study the camera controls and try the quiz'
    },
    {
      id: 'practice-makes-perfect',
      title: 'Practice Makes Perfect',
      description: 'Complete 10 practice sessions',
      icon: <CheckCircle className="h-5 w-5" />,
      category: 'learning',
      difficulty: 'silver',
      points: 40,
      unlocked: false,
      progress: 0,
      maxProgress: 10,
      requirements: ['Complete practice sessions'],
      hint: 'Regular practice is key to mastering photography'
    },
    {
      id: 'photography-guru',
      title: 'Photography Guru',
      description: 'Unlock all other achievements',
      icon: <Trophy className="h-5 w-5" />,
      category: 'mastery',
      difficulty: 'platinum',
      points: 200,
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      requirements: ['Complete all achievements'],
      hint: 'Master all aspects of photography to earn this ultimate achievement'
    }
  ]);

  const [totalPoints, setTotalPoints] = useState(0);
  const [newAchievements, setNewAchievements] = useState<string[]>([]);

  useEffect(() => {
    setAchievements(prevAchievements => {
      return prevAchievements.map(achievement => {
        let newProgress = achievement.progress;
        let unlocked = achievement.unlocked;

        switch (achievement.id) {
          case 'first-steps':
            if (userInteractions.settingsChanged > 0 && !unlocked) {
              newProgress = 1;
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'iso-explorer':
            const isoValues = [100, 400, 800, 1600, 3200];
            const matchedIsoValues = isoValues.filter(value => 
              Math.abs(settings.iso - value) <= 50
            );
            newProgress = Math.min(matchedIsoValues.length, achievement.maxProgress);
            if (newProgress === achievement.maxProgress && !unlocked) {
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'aperture-artist':
            const apertureValues = [1.4, 2.8, 8, 16];
            const matchedApertureValues = apertureValues.filter(value => 
              Math.abs(settings.aperture - value) <= 0.2
            );
            newProgress = Math.min(matchedApertureValues.length, achievement.maxProgress);
            if (newProgress === achievement.maxProgress && !unlocked) {
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'shutter-speed-master':
            const shutterValues = [1000, 250, 60, 15];
            const matchedShutterValues = shutterValues.filter(value => 
              Math.abs(settings.shutterSpeed - value) <= 10
            );
            newProgress = Math.min(matchedShutterValues.length, achievement.maxProgress);
            if (newProgress === achievement.maxProgress && !unlocked) {
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'quiz-champion':
            if (userInteractions.quizScore >= 100 && !unlocked) {
              newProgress = 1;
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'practice-makes-perfect':
            newProgress = Math.min(userInteractions.practiceSessionsCompleted, achievement.maxProgress);
            if (newProgress === achievement.maxProgress && !unlocked) {
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'exposure-triangle-expert':
            // Check for balanced exposure settings
            const ev = Math.log2((settings.aperture * settings.aperture) / (1/settings.shutterSpeed)) - Math.log2(settings.iso / 100);
            if (Math.abs(ev) <= 0.5 && settings.iso <= 800 && !unlocked) {
              newProgress = 1;
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;

          case 'photography-guru':
            const otherAchievements = prevAchievements.filter(a => a.id !== 'photography-guru');
            const completedCount = otherAchievements.filter(a => a.unlocked).length;
            if (completedCount === otherAchievements.length && !unlocked) {
              newProgress = 1;
              unlocked = true;
              setNewAchievements(prev => [...prev, achievement.id]);
            }
            break;
        }

        return { ...achievement, progress: newProgress, unlocked };
      });
    });
  }, [settings, userInteractions]);

  useEffect(() => {
    const points = achievements
      .filter(a => a.unlocked)
      .reduce((sum, a) => sum + a.points, 0);
    setTotalPoints(points);
  }, [achievements]);

  const getDifficultyColor = (difficulty: Achievement['difficulty']) => {
    switch (difficulty) {
      case 'bronze': return 'bg-amber-600 text-white';
      case 'silver': return 'bg-gray-400 text-white';
      case 'gold': return 'bg-yellow-500 text-white';
      case 'platinum': return 'bg-purple-600 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getCategoryColor = (category: Achievement['category']) => {
    switch (category) {
      case 'technical': return 'border-lens-blue';
      case 'creative': return 'border-warm-orange';
      case 'learning': return 'border-focus-green';
      case 'mastery': return 'border-purple-500';
      default: return 'border-gray-300';
    }
  };

  const dismissNewAchievement = (achievementId: string) => {
    setNewAchievements(prev => prev.filter(id => id !== achievementId));
  };

  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const completionPercentage = (unlockedCount / achievements.length) * 100;

  return (
    <div className="space-y-6">
      {/* New Achievement Notifications */}
      {newAchievements.length > 0 && (
        <div className="fixed top-4 right-4 z-50 space-y-2">
          {newAchievements.map(achievementId => {
            const achievement = achievements.find(a => a.id === achievementId);
            if (!achievement) return null;
            
            return (
              <Card key={achievementId} className="bg-focus-green border-focus-green shadow-lg animate-pulse">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-white rounded-full text-focus-green">
                        {achievement.icon}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">Achievement Unlocked!</h4>
                        <p className="text-sm text-white/90">{achievement.title}</p>
                      </div>
                    </div>
                    <Button
                      onClick={() => dismissNewAchievement(achievementId)}
                      variant="ghost"
                      size="sm"
                      className="text-white hover:bg-white/20"
                    >
                      ×
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Achievement Stats */}
      <Card className="bg-gradient-to-r from-lens-blue to-focus-green text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-6 w-6" />
            <span>Achievement Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{unlockedCount}/{achievements.length}</div>
              <div className="text-sm opacity-90">Unlocked</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{totalPoints}</div>
              <div className="text-sm opacity-90">Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{Math.round(completionPercentage)}%</div>
              <div className="text-sm opacity-90">Complete</div>
            </div>
          </div>
          <Progress value={completionPercentage} className="h-3" />
        </CardContent>
      </Card>

      {/* Achievement Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {achievements.map((achievement) => (
          <Card 
            key={achievement.id} 
            className={`relative transition-all hover:shadow-lg ${getCategoryColor(achievement.category)} border-2 ${
              achievement.unlocked ? 'bg-white' : 'bg-gray-50 opacity-75'
            }`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className={`p-2 rounded-lg ${
                  achievement.unlocked ? 'bg-focus-green text-white' : 'bg-gray-300 text-gray-500'
                }`}>
                  {achievement.unlocked ? achievement.icon : <Lock className="h-5 w-5" />}
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getDifficultyColor(achievement.difficulty)}>
                    {achievement.difficulty}
                  </Badge>
                  <span className="text-sm font-medium text-lens-blue">
                    {achievement.points} pts
                  </span>
                </div>
              </div>
              <CardTitle className="text-lg text-charcoal">{achievement.title}</CardTitle>
              <p className="text-sm text-charcoal/70">{achievement.description}</p>
            </CardHeader>

            <CardContent className="pt-0">
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-charcoal/70 mb-1">
                  <span>Progress</span>
                  <span>{achievement.progress}/{achievement.maxProgress}</span>
                </div>
                <Progress 
                  value={(achievement.progress / achievement.maxProgress) * 100} 
                  className="h-2" 
                />
              </div>

              {/* Requirements */}
              <div className="mb-4">
                <p className="text-sm font-medium text-charcoal mb-2">Requirements:</p>
                <ul className="space-y-1">
                  {achievement.requirements.map((req, index) => (
                    <li key={index} className="text-xs text-charcoal/70 flex items-start">
                      <span className="w-1 h-1 bg-warm-orange rounded-full mt-2 mr-2 flex-shrink-0"></span>
                      {req}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Hint */}
              {achievement.hint && !achievement.unlocked && (
                <div className="bg-lens-blue/10 rounded-lg p-3">
                  <p className="text-xs text-lens-blue">
                    💡 {achievement.hint}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}