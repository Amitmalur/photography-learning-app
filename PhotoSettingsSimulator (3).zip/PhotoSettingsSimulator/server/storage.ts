import { users, userProgress, quizResults, type User, type InsertUser, type UserProgress, type InsertUserProgress, type QuizResult, type InsertQuizResult } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserProgress(userId: number): Promise<UserProgress[]>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(userId: number, lessonId: string, completed: boolean, score?: number): Promise<UserProgress>;
  getQuizResults(userId: number): Promise<QuizResult[]>;
  createQuizResult(result: InsertQuizResult): Promise<QuizResult>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        level: 1,
        experience: 0,
        completedChallenges: []
      })
      .returning();
    return user;
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const [result] = await db
      .insert(userProgress)
      .values({
        ...progress,
        completed: false,
        completedAt: null
      })
      .returning();
    return result;
  }

  async updateUserProgress(userId: number, lessonId: string, completed: boolean, score?: number): Promise<UserProgress> {
    const [result] = await db
      .update(userProgress)
      .set({
        completed,
        score,
        completedAt: completed ? new Date() : null
      })
      .where(and(eq(userProgress.userId, userId), eq(userProgress.lessonId, lessonId)))
      .returning();
    return result;
  }

  async getQuizResults(userId: number): Promise<QuizResult[]> {
    return await db.select().from(quizResults).where(eq(quizResults.userId, userId));
  }

  async createQuizResult(result: InsertQuizResult): Promise<QuizResult> {
    const [quizResult] = await db
      .insert(quizResults)
      .values(result)
      .returning();
    return quizResult;
  }
}

export const storage = new DatabaseStorage();
