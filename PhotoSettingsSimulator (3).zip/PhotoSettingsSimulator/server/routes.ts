import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertUserProgressSchema, insertQuizResultSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ error: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  // User Progress routes
  app.get("/api/users/:id/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching user progress:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:id/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const progressData = insertUserProgressSchema.parse({
        ...req.body,
        userId
      });
      
      const progress = await storage.createUserProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      console.error("Error creating user progress:", error);
      res.status(400).json({ error: "Invalid progress data" });
    }
  });

  app.put("/api/users/:id/progress/:lessonId", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const lessonId = req.params.lessonId;
      const { completed, score } = req.body;
      
      const progress = await storage.updateUserProgress(userId, lessonId, completed, score);
      res.json(progress);
    } catch (error) {
      console.error("Error updating user progress:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Quiz Results routes
  app.get("/api/users/:id/quiz-results", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const results = await storage.getQuizResults(userId);
      res.json(results);
    } catch (error) {
      console.error("Error fetching quiz results:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:id/quiz-results", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const resultData = insertQuizResultSchema.parse({
        ...req.body,
        userId
      });
      
      const result = await storage.createQuizResult(resultData);
      res.status(201).json(result);
    } catch (error) {
      console.error("Error creating quiz result:", error);
      res.status(400).json({ error: "Invalid quiz result data" });
    }
  });

  // Health check route
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", database: "connected" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
